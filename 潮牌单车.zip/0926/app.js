//app.js
App({
  onLaunch: function () {
    wx.getSystemInfo({
      success: function (res) {  
        var kScreenW = res.windowWidth / 375;
        var kScreenH = res.windowHeight / 603;
        wx.setStorageSync('kScreenW', kScreenW)
        wx.setStorageSync('kScreenH', kScreenH)
        wx.setStorageSync('Height', res.windowHeight);
      }
    })
  },
  globalData: {
    getcode: "https://www.chaopaidanche.com/",

  }
})
