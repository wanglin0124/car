const app = getApp()
Page({
  data: {
    inputValue: '',//输入的手机号
    inputCode: '',//输入验证码
   getCodeBtnProperty: {  //获取验证码的颜色
       Background: '#f2f2f2',
      disabled: true,
      title: '60s',
      border: '2rpx solid rgb(246, 156, 40)'
    },
    misi:''
  },
  // //输入手机号
  // phoneTfInput: function (e) {
  //   var that = this;
  //   var inputValue = e.detail.value
  //   var length = e.detail.value.length;
  //   if (length == 11) {
  //     that.setData({
  //       inputValue: inputValue,
  //       focus_pwd: 'true',
  //       focus_user: false,
  //     })
  //   }
  // },
  //获取验证码
  getCodeAct: function () {
    var that = this;
    var inputValue = that.data.inputValue;
    if ((/^1[34578]\d{9}$/.test(inputValue))) {
      var code = 'App/V1/Login/userMobile';
      wx.request({
        url: app.globalData.getcode + code,
        data: { mobile: inputValue },
        method: 'POST', 
        header: {
          'content-type': 'application/x-www-form-urlencoded ' 
        },
        success: function (res) {
          console.log(res)
          var statu = res.data.code
          if (statu == '0') {
            wx.showToast({
              title: '发送成功',
              icon: 'success',
              duration: 2000,
            })
            //启动定时器
            var number = 60;
            var time = setInterval(function () {
              number--;
              that.setData({
                'getCodeBtnProperty.title': number + 's',
                'getCodeBtnProperty.disabled': true,
			    'getCodeBtnProperty.Background': '#f2f2f2',
                'getCodeBtnProperty.border': '2rpx solid rgb(246, 156, 40)',
              })
              if (number == 0) {
                that.setData({
                  'getCodeBtnProperty.title': '重新获取',
                  'getCodeBtnProperty.disabled': false,
				  'getCodeBtnProperty.border': '2rpx solid rgb(224, 224, 224)',
                  'getCodeBtnProperty.Background': 'rgb(224, 224, 224)',
                })
                clearInterval(time);
              }
            }, 1000);
          }else{
           wx.showModal({
             title: '警告!',
             content: res.data.info,
           })
          }
        },
        fail: function (res) {
          console.log(res)
        }
      })
    } else {
      wx.showModal({
        title: '提示',
        content: '手机号不正确',
        showCancel: false,
        success: function (res) {
          if (res.confirm) {
            console.log('用户点击确定')
          }
        }
      })
    }

  },
  //输入验证码
  codeTfInput: function (e) {
    var inputCode = e.detail.value;
    this.setData({
      inputCode:inputCode
    })
  },
  //注册登录
  login: function () {
    //光标取消
    var that = this;
    //请求接
    var login = 'App/V1/Login/userSign';
      //发起网络请求
      wx.request({
        url: app.globalData.getcode + login,
        data: {
          mobile: that.data.inputValue,
          misi:that.data.misi,
          code: that.data.inputCode
        },
        method: 'POST',
        header: {
          'content-type': 'application/x-www-form-urlencoded'
        },
        success: function (res) {
          console.log(res)
          var deposit = res.data.data.deposit
          wx.setStorageSync('deposit', deposit)
          var card = res.data.data.card
          var statu = res.data.code
          if (statu == 0) {
            wx.showToast({
              title: '请稍后',
              icon: 'loading',
              duration: 2000,
            })
            var token = res.data.data.token;
            wx.setStorageSync('token', token);//将token保存到程序内
            var user_id = res.data.data.id;
            wx.setStorageSync('user_id', user_id); //将user_id保存到程
            that.yearCard();//我的所有信息-学生认证
            var getOpenId = 'App/X1/Wxinfo/getOpenId';
            wx.request({
              url: app.globalData.getcode + getOpenId,
              data: {
                user_id: user_id,
                token: token,
                code: that.data.misi
              },
              method: 'POST',
              header: { 'content-type': 'application/x-www-form-urlencoded' },
              success: function (res) {
                console.log(res)
                wx.setStorageSync('openid', res.data.data);
                //转回主界面
                setTimeout(function () {
                  console.log(card)
                  if (card == 0) {
                    wx.setStorageSync('card', 0);
                    wx.navigateTo({
                      url: '../autonym/autonym',
                    })
                  } else if (deposit == '0.00' && wx.getStorageSync('studentauth')==2) {
                    console.log(card);
                    wx.setStorageSync('card', 2);
                      wx.navigateTo({
                        url: '../autonym/autonym',
                      })    
                  } else {
                    wx.setStorageSync('card', 2);
                    wx.reLaunch({
                      url: '../map/map',
                    })
                  }
                }, 1500)
              }
            })
          } else {
            wx.showModal({
              title: '提示',
              content: res.data.info,
            })
          }

        },
        fail: function (res) {
          console.log(res)
        }
      })

    
  },
  //收不到验证客服
  phone:function(){
    var that = this;
    wx.makePhoneCall({
      phoneNumber: '010-64826071',
      success: function () {
        console.log("拨打电话成功！");
      },
      fail: function () {
        console.log("拨打电话失败！");
      }
    })
  },
  yearCard() {
    var that = this
    var wechatApi = 'App/V1/Userinfomation/userInformation';
    wx.request({
      url: app.globalData.getcode + wechatApi,
      data: {
        token: wx.getStorageSync('token'),
        user_id: wx.getStorageSync('user_id'),
      },
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded '
      },
      success: function (res) {
        wx.setStorageSync('studentauth', res.data.data.studentauth)
      }
    })
  },
  onLoad:function(options){
    var that = this
    that.setData({
      inputValue: options.inputValue,
      misi:options.misi
    })
    //启动定时器
    var number = 60;
    var time = setInterval(function () {
      number--;
      that.setData({
        'getCodeBtnProperty.title': number + 's',
        'getCodeBtnProperty.disabled': true,
	    'getCodeBtnProperty.Background': '#f2f2f2',
        'getCodeBtnProperty.border': '2rpx solid rgb(246, 156, 40)',
      })
      if (number == 0) {
        that.setData({
          'getCodeBtnProperty.title': '重新获取',
          'getCodeBtnProperty.disabled': false,
	      'getCodeBtnProperty.border': '2rpx solid rgb(224, 224, 224)',
          'getCodeBtnProperty.Background': 'rgb(224, 224, 224)',
        })
        clearInterval(time);
      }
    }, 1000);
  },
  onShow:function(){
    if (wx.getStorageSync('token')) {
      wx.reLaunch({
        url: '../map/map',
      })
    }
  }
})
