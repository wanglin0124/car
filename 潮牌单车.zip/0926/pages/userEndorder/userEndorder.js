const app = getApp()
Page({
  data: {
      total:0,
      number:'',
      order_sn:'',
      price:''
  },
  affirm: function () {
    var that = this;
    var userPays = 'App/V1/Endstroke/userPays'
    wx.request({
      url: app.globalData.getcode + userPays,
      data: {
        order_sn: that.data.order_sn,
        token: wx.getStorageSync('token'),
        user_id: wx.getStorageSync('user_id')
      },
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded '
      },
      success: function (res) {
        // success
        console.log(res.data)
        if (res.data.code == '0') {
          wx.showModal({
            title: '提示',
            content: res.data.info,
            showCancel: false,
            success: function (res) {
              if (res.confirm) {
                console.log('用户点击确定');
                wx.reLaunch({
                  url: '../map/map',
                })
              }
            }
          })
        } else if (res.data.code == '1') {
          wx.showModal({
            title: '提示',
            content: res.data.info,
            showCancel: false,
            success: function (res) {
              if (res.confirm) {
                console.log('用户点击确定');
                wx.reLaunch({
                  url: '../map/map',
                })
              }
            }
          })
        }
      }
    })
  },
  pay: function () {
    var that=this;
    var userEndorder = 'App/V1/Consume/userEndorder';
    wx.request({
      url: app.globalData.getcode + userEndorder,
      data: {
        user_id: wx.getStorageSync('user_id'),
        token: wx.getStorageSync('token'),
        order_sn: that.data.order_sn,
        number: that.data.number
      },
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        console.log(res);
      },
      fail: function (res) {
        console.log(res)
      }
    })
  },
  onLoad: function (options) {
    this.setData({
      number: options.number,
      order_sn: options.order_sn,
      price: options.price,
      total: Number(options.price) + 50
    })
    this.pay()
  }
})