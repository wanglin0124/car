
var app = getApp();
//获取应用实例
Page({
  data: {
    time:'00:00:00',
    //开锁进度
    progress:1,
    number: '',//自行车序列号
    latitude: 0,  //用户当前位置
    longitude: 0,
    order_sn:''//订单号为下个页面传输值,暂时放在外面
  },
  //扫描二维码返回的事件
  scanBikeQr: function () {
    var that = this;
    var userUnlock = 'App/V2/Consume/userUnlock';
    wx.request({
      url: app.globalData.getcode + userUnlock,
      data: {
        user_id: wx.getStorageSync('user_id'),
        token: wx.getStorageSync('token'),
        number: that.data.number,
        longitude: that.data.longitude,
        latitude: that.data.latitude,
      },
      method: 'POST', 
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
          console.log(res);
          var factory = res.data.data.factory;
          if (res.data.code == 1){
            wx.setStorageSync('order_sn', res.data.data.order_sn);
            clearInterval(that.progress)
              wx.showModal({
                title: '提示',
                content: res.data.info,
                success: function (res) {
                  if (res.confirm) {
                    console.log('用户点击确定');
                  }
                  wx.redirectTo({
                    url: '../map/map'
                  })
                }
              })
            }       
          console.log(factory);
          if (factory == 1 || factory == 4) {
            clearInterval(that.progress)
            wx.setStorageSync('order_sn', res.data.data.order_sn);
            that.setData({
              progress: 100
            });
            var newDate = res.data.data.order_sn;
            var time_long = newDate.slice(0, 4) + '年' + newDate.slice(4, 6) + '月' + newDate.slice(6, 8) + '日 ' + newDate.slice(8, 10) + '时' + newDate.slice(10, 12) + '分' + newDate.slice(12, 14) + '秒'
            setTimeout(function () {
              wx.redirectTo({
                url: '../map/map?factory=' + res.data.data.factory
                + '&start_time=' + res.data.data.start_time
                + '&device=' + res.data.data.device
                + '&price=' + res.data.data.price
                + '&time_long=' + time_long + '&flagCode=' + 2
              })
            }, 4000)

          }
          //轮循是否开锁成功
          if (factory == 2 || factory == 3) {
            console.log('登录失败进行轮询');
            var number = 10;
            var time = setInterval(function () {
              number--;
              var lockStatus = 'App/V1/Consume/lockStatus';
              wx.request({
                url: app.globalData.getcode + lockStatus,
                data: {
                  user_id: wx.getStorageSync('user_id'),
                  token: wx.getStorageSync('token'),
                  number: that.data.number,
                  factory: factory,
                  device: res.data.data.device
                },
                method: 'POST',
                header: {
                  'content-type': 'application/x-www-form-urlencoded'
                },
                success: function (res) {
                  wx.setStorageSync('order_sn', res.data.data.order_sn);
                  console.log(res);
                  console.log('===========轮询次数' + number + '============');
                  var info2 = '网络信号不好，请用蓝牙开锁';
                  if (res.data.code == 0) {
                    clearInterval(that.progress)
                    that.setData({
                      progress: 100
                    })
                    var newDate = res.data.data.order_sn;
                    var time_long = newDate.slice(0, 4) + '年' + newDate.slice(4, 6) + '月' + newDate.slice(6, 8) + '日 ' + newDate.slice(8, 10) + '时' + newDate.slice(10, 12) + '分' + newDate.slice(12, 14) + '秒'
  
                    clearInterval(time);
                    setTimeout(function () {
                      wx.redirectTo({
                        url: '../map/map?factory=' + res.data.data.factory
                        + '&start_time=' + res.data.data.start_time
                        + '&device=' + res.data.data.device
                        + '&price=' + res.data.data.price
                        + '&time_long=' + time_long + '&flagCode=' + 2
                      })
                    }, 4000)
                 
                  
                    
                  }
                  if (res.data.code == 1) {
                    if (res.data.info == info2) { 
                      clearInterval(that.progress)
                      wx.showModal({
                        title: '提示',
                        content:'网络信号不好',
                        success: function (res) {
                          clearInterval(time);
                          wx.redirectTo({
                            url: '../map/map'
                          })
                        }
                      });
                    }
                  }
                  if (number == 0) {
                    clearInterval(that.progress)
                    wx.showModal({
                      title: '提示',
                      content: res.data.info,
                      showCancel: false,
                      success: function (res) {
                          wx.redirectTo({
                            url: '../map/map',
                          })
                      }
                    });
                    clearInterval(time);
                  }
                }
              });  
            }, 5000);
          }
      },
      fail: function (res) {
        // fail
        console.log(res)
      }
    })   
  },
  scanBikeQrAgain:function(){//电子围栏外单车信息
    var that = this;
    var userBluetoothmodel = 'App/V1/Electronic/userElectronic';
    wx.request({
      url: app.globalData.getcode + userBluetoothmodel,
      data: {
        user_id: wx.getStorageSync('user_id'),
        token: wx.getStorageSync('token'),
        number: that.data.number,
        order_sn: wx.getStorageSync('order_sn'),
      },
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        wx.getStorageSync('phoneShow') == '0'
        console.log(res);
        var factory = res.data.data.factory;
        console.log(factory);
        if (factory == 1 || factory == 4) {
          clearInterval(that.progress)
          that.setData({
            progress: 100
          });
          var newDate = res.data.data.order_sn;
          var time_long = newDate.slice(0, 4) + '年' + newDate.slice(4, 6) + '月' + newDate.slice(6, 8) + '日 ' + newDate.slice(8, 10) + '时' + newDate.slice(10, 12) + '分' + newDate.slice(12, 14) + '秒'
          wx.redirectTo({
            url: '../map/map?factory=' + res.data.data.factory
            + '&start_time=' + res.data.data.start_time
            + '&device=' + res.data.data.device
            + '&price=' + res.data.data.price
            + '&time_long=' + time_long+'&flagCode='+0,
          })
        }
        //轮循是否开锁成功
        if (factory == 2 || factory == 3) {
          console.log('登录失败进行轮询');
          var number = 10;
          var time = setInterval(function () {
            number--;
            var lockStatus = '/App/V1/Electronic/lockStatus';
            wx.request({
              url: app.globalData.getcode + lockStatus,
              data: {
                user_id: wx.getStorageSync('user_id'),
                token: wx.getStorageSync('token'),
                number: that.data.number,
                factory: factory,
                device: res.data.data.device,
                order_sn: wx.getStorageSync('order_sn')
              },
              method: 'POST',
              header: {
                'content-type': 'application/x-www-form-urlencoded'
              },
              success: function (res) {
                console.log(res);
                console.log('===========轮询次数' + number + '============');
                var info1 = '目前网络请求过多，请稍后重试';
                var info2 = '网络信号不好，请用蓝牙开锁';
                if (res.data.code == 0) {
                  clearInterval(that.progress)
                  that.setData({
                    progress: 100
                  });
                  var newDate = res.data.data.order_sn;
                  var time_long = newDate.slice(0, 4) + '年' + newDate.slice(4, 6) + '月' + newDate.slice(6, 8) + '日 ' + newDate.slice(8, 10) + '时' + newDate.slice(10, 12) + '分' + newDate.slice(12, 14) + '秒'
                
                    clearInterval(time);
                    wx.redirectTo({
                      url: '../map/map?factory=' + res.data.data.factory
                      + '&start_time=' + res.data.data.start_time
                      + '&device=' + res.data.data.device
                      + '&price=' + res.data.data.price
                      + '&time_long=' + time_long + '&flagCode=' + 0
                    })
                  
                  
                }
                if (res.data.code == 1) {
                  if (res.data.info == info2) {
                    clearInterval(that.progress)
                    wx.showModal({
                      title: '提示',
                      content: '网络信号不好',
                      showCancel: false,
                      success: function (res) {
                          wx.redirectTo({
                            url: '../map/map',
                          })
                      }
                    });
                  }
                }
                if (number == 0) {
                  clearInterval(that.progress)
                  wx.showModal({
                    title: '提示',
                    content: res.data.info,
                    showCancel: false,
                    success: function (res) {
                       clearInterval(time);
                        wx.redirectTo({
                          url: '../map/map'
                        })
                       
                    }
                  });
                  clearInterval(time);
                }
              }
            });
          }, 5000);
        }
      },
      fail: function (res) {
        // fail
        console.log(res)
      }
    })   
  },
  //页面加载的函数
  onLoad: function (options) {
    wx.setNavigationBarTitle({
      title: '扫码解锁'
    })
    //获取车牌号,设置定时器
    this.setData({
      number: options.number,//自行车序列号
      latitude:options.latitude,  
      longitude: options.longitude
    })
    if (options.lockAgain=='no'){
      this.scanBikeQr()
    }else{
      this.scanBikeQrAgain()
    }
    var num = 1;
    var that = this;
    this.progress = setInterval(function () {
      num++;
      that.setData({
        progress: num
      })
      if (that.data.progress == 100) {
        clearInterval(this.progress);
        wx.reLaunch({
          url: '../map/map',
        })
      }
    }, 500)
  },
  onHide:function(){
    wx.reLaunch({
      url:'../map/map'
    })
  }
})