var app = getApp();
Page({
  data: {
    price:'',
    order_sn:'',
  }, 
  onLoad: function (options) {
    console.log(options)
    this.setData({
      price:options.price,
      order_sn:options.order_sn
    })
  },
  affirm:function(){
    var that = this;
    var userPays = 'App/V1/Endstroke/userPays'
    wx.request({
      url: app.globalData.getcode + userPays,
      data: {
        order_sn: that.data.order_sn,
        token: wx.getStorageSync('token'),
        user_id: wx.getStorageSync('user_id')
      },
      method: 'POST', 
      header: {
        'content-type': 'application/x-www-form-urlencoded ' 
      },
      success: function (res) {
        // success
        console.log(res.data)
        if (res.data.code == '0') {
          wx.showModal({
            title: '提示',
            content: res.data.info,
            showCancel: false,
            success: function (res) {
              if (res.confirm) {
                console.log('用户点击确定');
                wx.reLaunch({
                  url: '../map/map',
                })
              }
            }
          })
        } else if (res.data.code == '1') {
          wx.showModal({
            title: '提示',
            content: res.data.info,
            showCancel: false,
            success: function (res) {
              if (res.confirm) {
                console.log('用户点击确定');
                wx.reLaunch({
                  url: '../map/map',
                })
              }
            }
          })
        }
      }
    })
  }
})