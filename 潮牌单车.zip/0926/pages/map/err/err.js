var app = getApp();
Page({
  data: {
    images:'../../../img/ico_repair_photo.png',
    size:'150rpx'
  },
  picture:function(){
    var that=this;
    wx.chooseImage({
      count: 1, // 默认9 
      success: function (res) {
        console.log(res);
        that.setData({
             size: '260rpx',
             images: res.tempFilePaths
          
      })
      }
    })
  },
  affirm:function(){
    var that=this;
    var userOutstandinga ='App/V1/Outstanding/userOutstandinga';
    console.log(String(that.data.images))
    wx.uploadFile({
      url: app.globalData.getcode + userOutstandinga, 
      filePath: String(that.data.images),
      name: 'file',
      formData: {
        user_id: wx.getStorageSync('user_id'),
        token: wx.getStorageSync('token'),
        images: that.data.images,
        type: 2      
      },
      method: 'POST',
      header: {
        'content-type': 'multipart/form-data'
      },
      success: function (res) {
        console.log(res)
        if (res.statusCode == 200) {
          wx.showToast({
            title: '上传成功',
            icon: 'success',
            duration: 2000,
            success: function () {
              setTimeout(function () {
                wx.navigateBack({
                  delta: 1
                })
              }, 1500)
            }
          })

        }
      }
    })  
  }
})