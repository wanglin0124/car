const app = getApp();
//获取应用实例
Page({
  data: {
    depositeText:'',
    paymentMoney:'',//余额
    //合并后的控件-------------------------------------------------------------
    header: false,//调用微信扫描时出现
    trip: false,  //骑行中的时间表
    tripOne: false, //骑行中的时间表缩回
    tripToggle: false,//骑行时出现
    order: false,//是否有订单
    centerOver: false,
    // customer: false,
    black:'black',
    deposit: false,
    tripTwo: false,//电动车
    school_id:'',//是否校内校外
    //地图样式--------------------------------------------------------------
    latitude: 0,  //用户当前位置
    longitude: 0,
    controls: [], //地图上不可移动的控件
    baginMapControls: [    //刚开始地图组件
      //扫描二维码控件按钮
      {
        id: 1,
        iconPath: '../../img/ico_usebicycle.png',
        position: {
          left: wx.getStorageSync('kScreenW') * 105,
          top: wx.getStorageSync('kScreenH') * 430,
          width: wx.getStorageSync('kScreenW') *170,
          height: wx.getStorageSync('kScreenH') * 170,
        },
        clickable: true
      },
      //个人中心按钮
      {
        id: 2,
        iconPath: '../../img/btn_usecenter.png',
        position: {
          left: wx.getStorageSync('kScreenW') * 300,
          top: wx.getStorageSync('kScreenH') * 520,
          width: wx.getStorageSync('kScreenW') * 50,
          height: wx.getStorageSync('kScreenH') * 50,
        },
        clickable: true
      },
      // //地图中心位置按钮
      {
        id: 3,
        iconPath: '../../img/ic_point.png',
        position: {
          left: wx.getStorageSync('kScreenW') * 178,
          top: wx.getStorageSync('kScreenH') * 269,
          width: wx.getStorageSync('kScreenW') * 20,
          height: wx.getStorageSync('kScreenH') *65,
        },
        clickable: false,
      },
      //显示位置按钮
      {
        id: 4,
        iconPath: '../../img/imgs_main_location@2x.png',
        position: {
          left: wx.getStorageSync('kScreenW') * 30,
          top: wx.getStorageSync('kScreenH') * 520,
          width: wx.getStorageSync('kScreenW') * 50,
          height: wx.getStorageSync('kScreenH') * 50,
        },
        clickable: true,
      },
      //活动页
      {
        id: 5,
        iconPath: '../../img/imgs_main_activity.png',
        position: {
          left: wx.getStorageSync('kScreenW') * 296,
          top: wx.getStorageSync('kScreenH') * 430,
          width: wx.getStorageSync('kScreenW') * 60,
          height: wx.getStorageSync('kScreenH') * 60,
        },
        clickable: true,
      }
    ],
    markers: [],// 标记数组
    Height: wx.getStorageSync('Height'), //地图的高
    mapScale:17,
    //画围栏-----------------------------------------------------------------
    poly: '',//为下一次判断围栏做准备放入对象
    noteinfo: '',
    polyline: [],
    //请求单车开锁参数,画围栏参数,扫描二维码时得到-----------------------------------------
    number: '',//自行车序列号
    numberShow:'',//展示到页面上
    //是否关锁轮询------------------------------------------------------------
    userLock: { 
      start_time: '',
      price: '',
      time_long: '', //轮询的time_long
    }, 
    unlockBikeParamsN: {
      factory: '', //车锁标识
      device: ''//车辆编号
    },
    end:'扫码骑回',//根据是否在围栏变换
    electronic: '2',//是否在围栏内
    time: '00:00:00',
    time_long:'',//屏幕的time_long
    order_sn: '',//计算行车进行中有退出的
    price: '0',   //为完成支付订单钱数
    flagCode:0,//情况一用来判断订单时间,第一次开锁与再次刷新进入
    isSecond:true ,
    lockAgain:'no',//判断是否再次开锁,
    tripChange:'show',

    timerOne:0,//onshow后的时间
    timerTwo:0,
    timerThree:0,
    member:''
  },
  //控件的点击事件
  controltap: function (e) {
    var that = this;
    var id = e.controlId
    if (id == 4) {
      //定位当前位置
      that.movetoPosition();
    } else if (id == 1) {  
        that.scancode()
    } else if (id == 2) {
      wx.navigateTo({
        url: '../wallet/wallet'
      })
    }else if(id==5){
      wx.navigateTo({
        url: 'activity/activity'
      })
    }
  },
  //未缴纳押金,去交押金
  deposit:function(){
    wx.navigateTo({
      url: '../autonym/autonym?deposit=1',
    })
  },
  //扫描二维码 
  scancode:function(){
    var that=this;
    console.log(that.data.paymentMoney <= 0, that.data.member == '0')
    that.setData({
      tripChange: 'hidden'
    })
    if (wx.getStorageSync('card') ==0){
      wx.showToast({
        title: '未实名认证',
        icon: 'loading',
      })
    } else if (wx.getStorageSync('deposit') == 0 && wx.getStorageSync('studentauth') == 2) {
      wx.showToast({
        title: '未交押金',
        icon: 'loading',
      })
    } else 
      if (that.data.paymentMoney <= 0 && that.data.member==0){
      wx.showModal({
        title: '提示!',
        content: '您的账户没有余额,充值后可立即用车!',
        confirmText:'充值',
        success: function (res) {
          console.log(res.confirm);
          if (res.confirm) {
            wx.navigateTo({
              url: '../wallet/recharge/recharge',
            })
          }
        }
      })
    } else{
      if(that.data.order){
        wx.showModal({
          title: '提示',
          content: '您还有未完成的订单!',
          showCancel:false
        })
      }else{
        wx.scanCode({
          success: function (res) {
            var number = res.result.match(/[=](\S*)/)[1];//number行车序列号
            console.log(number == that.data.number, that.data.number == '', that.data.number)
            if (that.data.number == '') {
              that.setData({
                numberAgain: true
              })
            }
            if (number == that.data.number || that.data.number == '') {
              that.setData({
                number: ''
              })
              // if (!that.data.number) {
              that.setData({
                numberShow: number,
                number: number,
                header: true,
                controls: [],
                markers: [],
                mapScale: 13,
                centerOver: false,
                // customer: false,
                tripToggle: false,
                black: false,
                toChange: false
              });
              wx.setNavigationBarTitle({
                title: '扫码解锁'
              })
              that.userBicycleType();
              // }
            } else {
              wx.showModal({
                title: '警告!',
                content: '请扫描原来的车辆!',
                showCancel: false
              })
            }
          },
          fail: function () {
            wx.showToast({
              title: '扫码失败',
              icon: 'loading',
              duration: 2000,
            })
          }
        })
      }
    }
  },
  //实时判断是否在围栏内外
  fence: function () {
    var that = this;
    wx.getLocation({
      type: 'gcj02',
      success: function (res) {
        var p = new Object();
        var poly = that.data.poly;
        // p.y = 39.005462;
        // p.x = 116.413856;
        p.y = res.latitude;
        p.x = res.longitude;
        for (var i = 0; i < poly.length; ++i) {
          var x = that.rayCasting(p, poly[i]);//判断点是否在面内
          console.log(x)
          if (x == 'on' || x == 'in') {//返回on||in在围栏内
          //在围栏内将1赋值给electronic,用于传入是否轮训管所接口的参数
            that.setData({
              electronic: '1' 
            })
            return;
          } else if (x == 'out') {//在围栏外
            that.setData({
              electronic: '2'
            })
          }
        }

      }
    })
  },
  //判断点是否在面内
  rayCasting: function (p, poly) {
    var px = p.x, py = p.y, flag = false;
    for (var i = 0, l = poly.length, j = l - 1; i < l; j = i, i++) {
      var sx = poly[i].x, sy = poly[i].y, tx = poly[j].x, ty = poly[j].y;
      // 点与多边形顶点重合
      if ((sx === px && sy === py) || (tx === px && ty === py)) {
        return 'on';
      }
      // 判断线段两端点是否在射线两侧
      if ((sy < py && ty >= py) || (sy >= py && ty < py)) {
        // 线段上与射线 Y 坐标相同的点的 X 坐标

        var x = sx + (py - sy) * (tx - sx) / (ty - sy)

        // 点在多边形的边上
        if (x === px) {
          return 'on';
        }

        // 射线穿过多边形的边界
        if (x > px) {
          flag = !flag
        }
      }
    }
    //表示在里面
    //点在面上返回的是on,在里面返回的是in，在外边返回的是out
    // 射线穿过多边形边界的次数为奇数时点在多边形内
    return flag ? 'in' : 'out'
  },
  //画出当前车子的围栏
  userBicycleType: function ( ) {
    var that = this;
    var userBicycleType = 'App/V1/Consume/userBicycleType';
    wx.request({
      url: app.globalData.getcode + userBicycleType,
      data: {
        user_id: wx.getStorageSync('user_id'),
        token: wx.getStorageSync('token'),
        number:that.data.number
      },
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        console.log(res)
        if (res.data.data.locks_status == 1 && that.data.numberAgain){
            that.setData({
              header: false,
              controls: that.data.baginMapControls,
              number: '',
            });
            wx.setNavigationBarTitle({
              title: '潮牌单车'
            })
            wx.showModal({
              title: '提示',
              content: '围栏外异常车辆，正在等待处理，请您选择其他车辆!',
              showCancel:false
            })
        }else{
          var enclosure = res.data.data.enclosure;
          //用x来代表数据源，数据源含有多个围栏对象，是一个数组
          var x = enclosure

          //这个len代表围栏数目
          var len = x.length;
          //记住数据源的地理围栏个数,创建围栏数组
          var arrs = new Array(len)
          //为下一次判断围栏做准备放入对象
          var poly = new Array(len)
          //构造每个围栏本身又是一系列GPS数据对象的数组
          for (var i = 0; i < len; ++i) {
            //为下一次判断围栏做准备放入对象
            poly[i] = [];

            arrs[i] = [];
            //xx代表当前对象
            var xx = x[i];
            //xx是对围栏对象的引用，我们对这个对象开始求值
            var tmp1 = xx.lolatitude;
            //拆分出含有对象的数据
            var tmparrfenhao = tmp1.split(";")
            //准备拆分出经纬度的数组
            var tmparrdouhao = [];
            //第一个数组对象，用来闭合围栏//准备一个对象，封闭围栏
            var obj = new Object();
            if (tmparrfenhao.length) {
              for (var j = 0; j < tmparrfenhao.length; ++j) {
                tmparrdouhao = tmparrfenhao[j].split(',');
                //如果是起始经纬度对象，就保存在准备好的对象里面
                if (j == 0) {
                  obj.longitude = tmparrdouhao[0];
                  obj.latitude = tmparrdouhao[1];
                }
                //向每个围栏里添加经纬度
                arrs[i].push({ 'longitude': tmparrdouhao[0], 'latitude': tmparrdouhao[1] });
                //为下一次判断围栏做准备放入对象
                poly[i].push({ 'x': Number(tmparrdouhao[0]), 'y': Number(tmparrdouhao[1]) })
              }
            }

            //临门一脚，把围栏的经纬度数据分别抓起来关闭
            arrs[i].push(obj)
          }
          //此时，不管有多少围栏，每次要绘制的圈，坐标数据都保存在arrs里面,这个数组里面
          //  console.log(arrs,poly)
          //最外层大数组，存放围栏
          var polyline = new Array(len);
          for (var k = 0; k < len; ++k) {
            //放围栏的对象
            polyline[k] = new Object()
            var obj = polyline[k];
            obj.points = arrs[k];
            obj.color = "#FF0000DD",
              obj.width = 2,
              obj.borderWidth = 7
          }

          that.setData({
            noteinfo: res.data.data.noteinfo,
            polyline: polyline,
            poly: poly,
            school_id: res.data.data.school_id
          })
        }
      }
    })
  },
  //点击立即用车,跳转开锁页面
  scanBikeQr:function(){
    var that=this;
    clearInterval(that.fenceUserElectornicorder);
    clearInterval(that.timerTwo);
    clearInterval(that.timerOne)
    wx.redirectTo({
      url: '../unlocking/unlocking?number=' + this.data.number + '&latitude=' + this.data.latitude + '&longitude=' + this.data.longitude + '&lockAgain=' + that.data.lockAgain,
      success:function(){
        that.setData({
          controls: [],
          black: false,
        })
      }
   })
  },
  //取消用车
  cancel:function(){
    console.log(this.data.end)
    if (this.data.end == '扫码骑回' && this.data.flagCode==2){
      this.setData({
        header: false,
        tripChange: 'show',
        tripToggle:true,
        centerOver: true,
        // customer: true,
        controls:[],
      })
    }else{
      this.setData({
        controls: this.data.baginMapControls,
        header: false,
        polyline: [],
        number: '',
        tripChange: 'show',
        black: true
      })
      this.getBikeList();
      this.movetoPosition();
    }
  },
  // 地图视野改变事件
  bindregionchange: function (e) {
    var that = this; 
    if (that.data.trip == false && !that.data.number&&that.data.tripChange=='show') {//如果在进行时就不会刷新单车&&扫描二维码时同样
      that.mapCtx.getCenterLocation({
        success: function (res) {
          if (e.type == "begin") { // 拖动地图，获取附件单车位置
            // console.log('开始刷新')   
          } else if (e.type == "end") {// 停止拖动，显示单车位置
            //刷新单车列表
            that.setData({
              tripChange:'show'
            })
            that.getBikeList(res.latitude, res.longitude);  
          }
        }
      })
    }
  },
  //请求附近单车列表
  getBikeList: function (latitude, longitude) {
    var that = this;
    var equipmentIndex = 'App/V1/Equipment/equipmentIndex'
    wx.request({
      url: app.globalData.getcode + equipmentIndex,
      data: {
        user_id: wx.getStorageSync('user_id'),
        token: wx.getStorageSync('token'),
        y: longitude,
        x: latitude
      },
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        console.log('附近单车列表')
        console.log(res);
        if (res.data.code == 0) {
          that.order();//查询是否有没完成的订单
          var iconPath = '../../img/ico_landmark_bicycle.png';
          var bikeArr = res.data.data;
          //附近单车
          var markers = [];
          if(bikeArr.length>40){//最多只返回40辆
            for (var i = 0; i <= 40; ++i) {
              var marker = {
                latitude: Number(bikeArr[i].latitude),
                longitude: Number(bikeArr[i].longitude),
                iconPath: iconPath,
                id: i,
                width: 36,
                height: 40
              }
              markers.push(marker)
            }
          }else{//小于40辆的显示
            bikeArr.forEach(function (item, index) {
            var marker = {
              latitude: Number(item.latitude),
              longitude: Number(item.longitude),
              iconPath: iconPath,
              id: index,
              width: 36,
              height: 40
            }
            markers.push(marker)
          })
          } 
          that.setData({
            markers: markers
          })
          
        } else if (res.data.code == 1) {
          wx.setStorageSync('order_sn', res.data.data.order_sn);
          if (res.data.data.flag == 0) {//代表正在进行的行程，根据需求需要跳转正在进行行程页面
            wx.setNavigationBarTitle({
              title: '正在骑行'
            })
            var newDate = res.data.data.order_sn;
            var time_long = newDate.slice(0, 4) + '年' + newDate.slice(4, 6) + '月' + newDate.slice(6, 8) + '日 ' + newDate.slice(8, 10) + '时' + newDate.slice(10, 12) + '分' + newDate.slice(12, 14) + '秒'
            
            that.setData({
              trip: true,
              tripToggle: true,
              unlockBikeParamsN: {
                factory: res.data.data.factory, //车锁标识
                device: res.data.data.device//车辆编号
              },
              userLock: {
                start_time: res.data.data.start_time,
                price: res.data.data.price,
                time_long: res.data.data.time_long
              },
              number: res.data.data.number,
              numberShow: res.data.data.number,
              order_sn: res.data.data.order_sn,
              controls: [],
              markers:[],
              time_long: time_long,
              price: res.data.data.price,
              // customer: true,
              black: false
            })
            that.userBicycleType();
            that.userLock();
          } else if (res.data.data.flag == 5) {//代表电子围栏外订单，根据需求需要跳转电子围栏外订单轮循，30min一次
            wx.setNavigationBarTitle({
              title: '扫码骑回'
            })
        
              var time = res.data.data.start_time;//开始骑行的时间
              var now = parseInt(new Date().valueOf() / 1000);//当前时间戳	 	
              var date = now - time;
              var hour = Math.floor(date / 3600);
              var minute = Math.floor((date % 3600) / 60);
              var second = date % 60;
              if (second.toString().length == 1) {
                second = '0' + second
              }
              if (hour.toString().length == 1) {
                hour = '0' + hour
              }
              if (minute.toString().length == 1) {
                minute = '0' + minute
              }
              that.setData({
                time: hour + ":" + minute + ":" + second,
                userLock: {
                  start_time: res.data.data.start_time,
                  price: res.data.data.price,
                  time_long: res.data.data.time_long
                }
              })
                that.setData({
                  controls: [],
                  centerOver: true,
                  price: res.data.data.price,
                  time: that.data.time,
                  order_sn: res.data.data.order_sn,
                  numberShow: res.data.data.number,
                  number: res.data.data.number,
                  tripToggle: true,
                  // customer: true,
                  black: false,
                  trip: false,
                  tripOne: false
                })
                console.log(that.data.header)
                if (that.data.header == true) {
                  that.setData({
                    centerOver: false,
                    // customer: false,
                    tripToggle: false
                  })
                }
              
            that.userTraining();//关锁后电子围栏外轮训
            that.userBicycleType();
            //在围栏外关锁有可能是经纬度原因,之后要定时器判断是否在围栏,改变状
            if (that.data.timerThree == 0 && that.data.timerOne == 0){
              that.fenceUserElectornicorder = setInterval(function () {
                var time = that.data.userLock.start_time;//开始骑行的时间
                var now = parseInt(new Date().valueOf() / 1000);//当前时间戳	 	
                var date = now - time;
                var hour = Math.floor(date / 3600);
                var minute = Math.floor((date % 3600) / 60);
                var second = date % 60;
                if (second.toString().length == 1) {
                  second = '0' + second
                }
                if (hour.toString().length == 1) {
                  hour = '0' + hour
                }
                if (minute.toString().length == 1) {
                  minute = '0' + minute
                }
                that.setData({
                  time: hour + ":" + minute + ":" + second
                })
                console.log(that.data.time + 'three')

                that.fence();
                that.userElectornicorder();
                if (that.data.electronic == '1') {
                  that.setData({
                    end: '结束行程'
                  })
                  clearInterval(that.fenceUserElectornicorder)
                }
              }, 1000)
              that.setData({
                timerThree: 1
              })
            }  
          }
        }
      },
      fail: function (res) {
        console.log(res)
      }
    })
  },
  // 定位函数，移动位置到地图中心
  movetoPosition: function () {
    var that = this
    that.mapCtx.moveToLocation();
    that.setData({
      mapScale: 17,
    })
    
  },
  //轮询是否关锁
  userLock:function(){         
    var that=this;
    if (that.data.flagCode == '2'){
      if (that.data.timerOne == 0) {
        var hour = '00';
        var minute = '00';
        var second = 0;//时 分 秒
        that.timerOne = setInterval(function () {
          if (second < 10) {
            second = "0" + second;
          }
          that.setData({
            time: hour + ':' + minute + ':' + second
          })
          console.log(that.data.time)
          second++;
          if (second >= 60) {
            second = 0;
            minute++;
            if (minute < 10) {
              minute = "0" + minute;
            }
          }
          if (minute >= 60) {
            minute = '00';
            hour++;
            if (hour < 10) {
              hour = "0" + hour;
            }
          }

        }, 1000);
        that.setData({
          timerOne: 1
        })
      }
    } else{
      if(that.data.timerTwo==0&&that.data.timerThree==0){
        that.timerTwo = setInterval(function () {
          var time = that.data.userLock.start_time;//开始骑行的时间
          var now = parseInt(new Date().valueOf() / 1000);//当前时间戳	 	
          var date = now - time;
          var hour = Math.floor(date / 3600);
          var minute = Math.floor((date % 3600) / 60);
          var second = date % 60;
          if (second.toString().length == 1) {
            second = '0' + second
          }
          if (hour.toString().length == 1) {
            hour = '0' + hour
          }
          if (minute.toString().length == 1) {
            minute = '0' + minute
          }
          that.setData({
            time: hour + ":" + minute + ":" + second
          })
          console.log(that.data.time + 'two')
        }, 1000)
       that.setData({
         timerTwo:1
       })
      }
    }
    var svip = ''
    this.ridingTimer = setInterval(function (){
      if (that.data.school_id != 0 && that.data.member != '0') {
        svip = 1
      } else {
        svip = 2
      }
      var userLock = 'App/V1/Round/userLock';
      var ele='';
      wx.request({
        url: app.globalData.getcode + userLock,
        data: {
          user_id: wx.getStorageSync('user_id'),
          token: wx.getStorageSync('token'),
          factory: that.data.unlockBikeParamsN.factory,
          device: that.data.unlockBikeParamsN.device,
          start_time: that.data.userLock.start_time,
          price: that.data.userLock.price,
          time_long: that.data.userLock.time_long,
          electronic: that.data.electronic,
          svip: svip
        },
        method: 'POST',
        header: {
          'content-type': 'application/x-www-form-urlencoded'
        },
        success: function (res) {
          console.log(res);
          that.fence();//判断是否在围栏内外
          if (that.data.isSecond==false){
            clearInterval(that.ridingTimer);
          }
          if (res.data.code == 1) {//code=1时没有关锁
            that.setData({
              price: res.data.data.price,
              markers:[]
            })
          } else if (res.data.code == 0) {//code=0时关锁
            clearInterval(that.ridingTimer);
            //此时做判断,因为定时器关闭后没有立即执行,又再次调用一次,造成进入了两次支付页面
            if(that.data.isSecond){//全局true
              that.setData({
                isSecond:false //进入一次改为false,不会再次进入
              })
              that.setData({
                price: res.data.data.price,
                electronic: res.data.data.electronic
              })
              if (res.data.data.electronic == '1') {//围栏内正常支付
                if (that.data.flagCode == '2') {
                  clearInterval(that.timerOne);
                } else {
                  clearInterval(that.timerTwo);
                }
                console.log("定时器停止");
                that.userPay()  //进入消费订单,判断是否钱够
              } else if (res.data.data.electronic == '2') {//围栏外扫码骑回
                console.log("定时器停止");        
                that.setData({
                  centerOver: true,//扫码骑回
                  trip: false
                })
                that.userTraining();//关锁后电子围栏外轮训
                //在围栏外关锁有可能是经纬度原因,之后要定时器判断是否在围栏,改变状态
                that.fenceUserElectornicorder = setInterval(function () {
                  that.fence(); 
                  that.userElectornicorder();
                  if (that.data.electronic == '1') {
                    that.setData({
                      end: '结束行程'
                    })
                    clearInterval(that.fenceUserElectornicorder);
                  }
                },1000)
              }
            }
          }
        }
      })
    },5000)
  },
  //电子围栏外轮训价格（30min轮循取到最新价格）：
  userTraining:function(){
    this.timer = setInterval(function () {
      var that=this;
      var userTraining='App/V1/Electronic/userTraining';
      wx.request({
        url: app.globalData.getcode + userTraining,
        data: {
          user_id: wx.getStorageSync('user_id'),
          token: wx.getStorageSync('token'),
          start_time:that.data.userLock.start_time,
          time_long: that.data.userLock.time_long,
          price: that.data.price, 
          number: that.data.number
        },
        method: 'POST',
        header: {
          'content-type': 'application/x-www-form-urlencoded'
        },
        success: function (res) {
          console.log(res);
          that.setData({
            price:res.data.price
          })
        },
        fail: function (res) {
          console.log(res)
        }
      })
    },1800000)

  },
  //用户在电子围栏外结束行程订单完成
  userElectornicorder: function () {
    var that = this;
    var userElectornicorder = 'App/V1/Userinfo/userElectornicorder';
    wx.request({
      url: app.globalData.getcode + userElectornicorder,
      data: {
        user_id: wx.getStorageSync('user_id'),
        token: wx.getStorageSync('token'),
        order_sn: that.data.order_sn,
        electronic: that.data.electronic,
        number: that.data.number
      },
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        console.log(res);
      },
      fail: function (res) {
        console.log(res)
      }
    })
  },
  //获取用户消费订单信息
  userPay: function () {
    var that = this;
    var userPay = 'App/V1/Consume/userPay';
    wx.request({
      url: app.globalData.getcode + userPay,
      data: {
        order_sn: that.data.order_sn,
        token: wx.getStorageSync('token'),
        user_id: wx.getStorageSync('user_id')
      },
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded ' // 默认值
      },
      success: function (res) {
        console.log(res.data)
        if (res.data.code == '0') {
          that.setData({
            price: res.data.data.price
          })
          that.payment();//进入我的钱包,做判断
        } 
      },
      fail: function (res) {
        console.log(res)
      }
    })
  },
  //查看我的钱包
  payment: function () {
    var that = this;
    var userMoney = 'App/V1/Userinfomation/userMoney';
    wx.request({
      url: app.globalData.getcode + userMoney,
      data: {
        token: wx.getStorageSync('token'),
        user_id: wx.getStorageSync('user_id')
      },
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded ' // 默认值
      },
      success: function (res) {
        console.log(res.data)
        if (res.data.code == '0') {
          var money = res.data.data.money;
          console.log(that.data.price, money)
          //钱包钱够直接付款      
          if (parseInt(money) >= parseInt(that.data.price)) {
            wx.navigateTo({
              url: '../payment/payment?price=' + that.data.price + '&order_sn=' + that.data.order_sn,
            })      
          } else{
            wx.navigateTo({
              url: '../selectPayment/selectPayment?price=' + that.data.price + '&order_sn=' + that.data.order_sn,
            })
          }
        } else if (code == '1') {
          wx.showModal({
            title: '提示',
            content: res.data.info,
            showCancel: false,
            success: function (res) {
              if (res.confirm) {
                console.log('用户点击确定');
              }
            }
          })
        }
      },
      fail: function (res) {
        console.log(res)
      }
    })
  },
  //查看是否有未完成的订单
  order: function () {
    var that = this;
    var userBicycleType = 'App/V1/Consume/userBicycleType';
    wx.request({
      url: app.globalData.getcode + userBicycleType,
      data: {
        user_id: wx.getStorageSync('user_id'),
        token: wx.getStorageSync('token'),
      },
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        if (res.data.data.order) {
          clearInterval(this.fenceUserElectornicorder)
          that.setData({
            polyline: [],
            order: true,
            black: false,
            trip: false,
            tripOne: false,
            centerOver: false,
            tripToggle: false,
            // customer: false,
            controls: that.data.baginMapControls,
            price: res.data.data.order.price,
            order_sn: res.data.data.order.order_sn
          })
        }
      }
    })
  },
  //有未完成订单去支付
  orderTap: function () {
    this.payment()
  },
  //无法结束行程错误照片
  err: function () {
    wx.navigateTo({
      url: 'err/err',
    })
  },
  //扫码骑回 
  imageOver:function(){
    if(this.data.end=='扫码骑回'){
      this.setData({
       lockAgain:'is'
      })
      this.scancode();
    }else{
      clearInterval(this.fenceUserElectornicorder);
      this.userPay();
    } 
  },
  //立即支付
  imageOverOne:function(){
    var that=this;
    wx.showModal({
      title: '涉及您的权益,请注意',
      content: '该操作仅用于车子骑出红线区域后不方便骑回还车的用户,托运费50元(该笔费用将用于专人召回车辆,此费用不包含本次行程费用),如果已确定车辆停放在红线区域内请致电客服.',
      confirmText:'支付运费',
      success: function (res) {
        if (res.confirm) {   
          clearInterval(that.fenceUserElectornicorder);
          clearInterval(that.ridingTimer);
          clearInterval(that.timerOne);
          wx.navigateTo({
            url: '../userEndorder/userEndorder?price='+that.data.price+'&number='+that.data.number+'&order_sn='+that.data.order_sn,
          })
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },
  //客服电话
  customer:function(){
    var that=this;
    wx.makePhoneCall({
      phoneNumber: '010-64826071'
    })
  },
  trip:function(){//缩回
    this.setData({
      trip: false,
      tripOne: true
    })
  },
  tripOne:function(){
    this.setData({
      trip: true,
      tripOne: false
    })
  },
  //查看余额
  paymentMoney: function () {
    var that = this;
    var userMoney = 'App/V1/Userinfomation/userMoney';
    wx.request({
      url: app.globalData.getcode + userMoney,
      data: {
        token: wx.getStorageSync('token'),
        user_id: wx.getStorageSync('user_id')
      },
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded ' // 默认值
      },
      success: function (res) {
        console.log(res);
        that.setData({
          paymentMoney: parseInt(res.data.data.money),
          member:res.data.data.member
        })
        if (wx.getStorageSync('user_id')) {
          if (wx.getStorageSync('card') == 0) {
            that.setData({
              deposit: true,
              black: false,
              depositeText: '您还未实名认证,点我快速认证!'
            })
          } else if (wx.getStorageSync('deposit') == 0 && wx.getStorageSync('studentauth') == 2) {//
            that.setData({
              deposit: true,
              black: false,
              depositeText: '您还未缴纳押金,点我快速缴纳!',
            })
          }
        }
      },
      fail: function (res) {
        console.log(res)
      }
    })
  },
  //页面加载的函数
  onLoad: function (options) {
    console.log('onload')
    var that = this;
    that.setData({
      number: ''
    })
    if (options.factory){//有正在进行的订单
      wx.setNavigationBarTitle({
        title: '正在骑行'
      })
      that.setData({
        userLock: {
          start_time: options.start_time ,
          price: options.price,
          time_long: options.time_long
        },
        unlockBikeParamsN: {
          factory: options.factory, //车锁标识
          device: options.device//车辆编号
        },
        order_sn:wx.getStorageSync('order_sn'),
        controls: [],
        black: false,
        trip: true,
        flagCode: options.flagCode,
        // customer: true,
        mapScale: 13,
      });
    }else{
      that.setData({
        controls: that.data.baginMapControls,
      });
    }
    
  },
  onShow: function () {
    console.log('onshow');
    var that = this;
    that.paymentMoney();
    wx.setNavigationBarTitle({
      title: '潮牌单车'
    })
    that.getBikeList();//查询附近车辆,与正在进行中的订单
    if (!wx.getStorageSync('token')) {
      setTimeout(function(){
        wx.navigateTo({
          url: '../login/login',
        })
      },1000)
    }
    //获取用户的当前位置位置
    wx.getLocation({
      type: 'gcj02',
      success: function (res) {
        that.setData({
          latitude: res.latitude,
          longitude: res.longitude,
        })
      }
    })
    // 1.创建地图上下文，移动当前位置到地图中心
    this.mapCtx = wx.createMapContext("myMap"); // 地图组件的id
    this.movetoPosition();
  },
  onHide:function(){
    console.log('onHide')
  },
  onUnload:function(){
    console.log('onUnload')
  },
  onShareAppMessage: function () {
    return {
      title: '潮牌单车',
      imageUrl: '../../img/3.jpg',
      path: '/pages/map/map' // 分享路径
    }
  }
})