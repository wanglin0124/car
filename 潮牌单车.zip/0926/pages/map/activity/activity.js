const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: { },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function () {
    var that = this;
    var engageActivity = 'App/V1/Activity/engageActivity';
    wx.request({
      url: app.globalData.getcode + engageActivity,
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded '
      },
      success: function (res) {
        console.log(res)
        var active=res.data.data;
        that.setData({
          active: active
        })
        console.log(that.data.active)
      },
    })
  },
})