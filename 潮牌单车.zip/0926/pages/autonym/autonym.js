var app = getApp();
Page({
  data: {
    // 点击按钮
    proceed: 'proceed',
    proceed1: '',
    proceed2: '',
    // 页面切换
    change:'block',
    change1: 'none',
    change2: 'none',
    common: 'block',
    img:'../../img/attention.png',
    imgErr:'../../img/default_icon.png',
    imgNo:'../../img/default_icon.png',
    card:'',//身份证号
    username:'',//用户名
    clicktag:0,
    checked:"none",
    array:'',
    index: 0,
    studentauth: '',    //学号
    school_id:'1',
  },
  bindPickerChange: function (e) {
    var that = this;
    console.log('picker发送选择改变，携带值为', e.detail.value);
    this.setData({
      index: e.detail.value,
      school_id: that.data.array[e.detail.value].id
    })
    console.log(that.data.school_id)
  },
  onLoad: function () {
    var that = this;
    var wechatApi = 'App/V1/Students/schoolInfo';
    wx.request({
      url: app.globalData.getcode + wechatApi,
      data: {
        token: wx.getStorageSync('token'),
        user_id: wx.getStorageSync('user_id'),
      },
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded '
      },
      success: function (res) {
        console.log(res.data.data)
        that.setData({
          array: res.data.data
        })
      }
    })
    if (wx.getStorageSync('card')==0){
      wx.setNavigationBarTitle({
        title: '实名认证'
      })    
    } else if (wx.getStorageSync('deposit') == 0){
      wx.setNavigationBarTitle({
        title: '押金充值'
      })
      this.setData({
        proceed: '',
        proceed1: 'proceed',
        change: 'none',
        change1: 'block',
        img: '../../img/complted.png',
        imgErr: '../../img/attention.png',
      });
    }
  },
  checked(e){//选中时时间
    console.log(e);
    if(e.currentTarget.dataset.check=='none'){
      this.setData({
        checked:''
      })
    }else{
      this.setData({
        checked: 'none'
      })
    }
  },
  idName(e){
    var that = this;
    that.setData({
      username: e.detail.value
    }) 
  },
  idNumber:function(e){
    var that = this;
    that.setData({
      card:e.detail.value
    }) 
  },
  // 提交资料
  login: function () {
    var that = this;
    if (that.data.username==''){
      wx.showModal({
        title: '提示',
        content: '姓名不能为空',
        showCancel: false
      })
    }else{
      if ((/^[1-9]\d{7}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}$|^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}([0-9]|X)$/.test(that.data.card))) {
        var that = this;
        var userCard = 'App/V1/Userinfo/userCard';
        wx.request({
          url: app.globalData.getcode + userCard,
          data: {
            user_id: wx.getStorageSync('user_id'),
            token: wx.getStorageSync('token'),
            username: that.data.username,
            card: that.data.card,
          },
          method: 'POST',
          header: {
            'content-type': 'application/x-www-form-urlencoded '
          },
          success: function (res) {
            console.log(res.data)
            var statu = res.data.code
            if (statu == '0') {
              wx.setStorageSync('card', 2);
              if (that.data.checked == 'none') {
                 that.setData({
                    proceed: '',
                    proceed1: 'proceed',
                    change: 'none',
                    change1: 'block'
                  });
                 wx.showToast({
                   title: '认证成功',
                   icon: 'success',
                   duration: 2000,
                 })
              } else {
                that.affirmStudent()
              }        
              wx.setNavigationBarTitle({
                title: '押金充值'
              })
            } else {
              wx.showModal({
                title: '提示',
                content: res.data.info,
                showCancel: false
              })
            }
          }
        })

      } else if (!that.data.card) {
        wx.showModal({
          title: '提示',
          content: '身份证号不能为空!',
          showCancel: false
        })
      } else {
        wx.showModal({
          title: '提示',
          content: '身份证号错误!',
          showCancel: false
        })
      }
    }
  },
  studentauth(e) {
    var that = this;
    that.setData({
      studentauth: e.detail.value
    })
  },
  // 上传学生认证信息
  affirmStudent: function () {
    var that = this;
    var wechatApi = 'App/V1/Students/studentInfo';
    wx.request({
      url: app.globalData.getcode + wechatApi,
      data: {
        token: wx.getStorageSync('token'),
        user_id: wx.getStorageSync('user_id'),
        username: that.data.username, //真实姓名
        studentauth: that.data.studentauth,    //学号
        school_id: that.data.school_id     //学校

      },
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded '
      },
      success: function (res) {
        console.log(res.data)
        if (res.data.code == 0) {
          that.setData({
            common: 'none',
            proceed: '',
            proceed1: '',
            proceed2: 'proceed',
            change: 'none',
            change1: 'none',
            change2: 'block',
            imgErr: '../../img/complted.png',
            imgNo: '../../img/default_icon.png',
            experience: '购买校园卡'
          })
          wx.setNavigationBarTitle({
            title: '完成'
          })
          wx.setStorageSync('studentauth','1')
          wx.showToast({
              title: '成功',
              icon: 'success',
              duration: 1000
          })
        } else {
          wx.showModal({
            title: '提示',
            content: res.data.info,
            showCancel: false
          })
        }
      }
    })

  },
  // 确认支付
  affirm:function(){
    var that = this;
    if (that.data.clicktag == 0) {
      that.setData({
        clicktag: 1
      })
      setTimeout(function () {
        that.setData({
          clicktag: 0
        })
      }, 2000);
      var wechatApi ='App/X1/Wxinfo/userPay';
      wx.request({
        url: app.globalData.getcode + wechatApi,
        data: {
          token: wx.getStorageSync('token'),
          user_id: wx.getStorageSync('user_id'),
          openid: wx.getStorageSync('openid'),
          price:199,
          type: 2
        },
        method: 'POST',
        header: {
          'content-type': 'application/x-www-form-urlencoded '
        },
        success: function (res) {
          console.log(res.data)
          if (res.data.code == 0) {
            console.log(res.data.data);
            var obj = JSON.parse(res.data.data)
            wx.requestPayment({
              'timeStamp': obj.timeStamp,
              'nonceStr': obj.nonceStr,
              'package': obj.package,
              'signType': 'MD5',
              'paySign': obj.paySign,
              success: function (res) {
                wx.setStorageSync('deposit', 199.00)
                console.log(res);
                wx.showModal({
                  title: '支付结果',
                  content: '恭喜您,支付成功!',
                  showCancel:false,
                  success:function(){
                    that.setData({
                      common: 'none',
                      proceed1: '',
                      proceed2: 'proceed',
                      change1: 'none',
                      change2: 'block',
                      imgErr: '../../img/complted.png',
                      imgNo: '../../img/default_icon.png',
                      experience: '立即体验'
                    })
                    wx.setNavigationBarTitle({
                      title: '完成'
                    })
                  }
                })
              }
            })
          }
        }
      })
    }
  },
  // 充值
  recharge:function(){
    if (wx.getStorageSync('studentauth')==1){
      wx.navigateTo({
        url: '../wallet/wallet'
      })
    }else{
      wx.navigateTo({
        url: '../wallet/recharge/recharge'
      })
    }
  },
  // 立即体验
  experience:function(){
    if (this.data.experience =='购买校园卡'){
      wx.navigateTo({

        url: '../wallet/yearCard/yearCard'
      })
    }else{
      wx.redirectTo({
        url: '../map/map'
      })
    }
  }
})
