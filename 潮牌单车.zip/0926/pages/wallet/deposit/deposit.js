var app = getApp();
Page({
  data:{
    deposit:'0.00',
    text:'退押金'
  },
  onLoad:function(options){
    this.setData({
      deposit: options.deposit
    });
    if(this.data.deposit=='0.00'){
      this.setData({
        text: '缴纳押金'
      })
    }
  },
  recharge:function(){
    var that=this;
    if(that.data.text=='退押金'){
      wx.showModal({
        title: '提示!',
        content: '小主~以后要交299元押金了!您真的要退吗?',
        success: function (res) {
          console.log(res.confirm)
          if (res.confirm) {
            var result = 'App/V1/Refund/result';
            wx.request({
              url: app.globalData.getcode + result,
              data: {
                token: wx.getStorageSync('token'),
                user_id: wx.getStorageSync('user_id'),
                prices: that.data.deposit
              },
              method: 'POST',
              header: {
                'content-type': 'application/x-www-form-urlencoded '
              },
              success: function (res) {
                that.setData({
                  text :'缴纳押金',
                  deposit:'0.00'
                })
                wx.setStorageSync('deposit', 0.00)
                console.log(res)
                if (res.code != 1) {
                  wx.showModal({
                    title: '恭喜',
                    content: '退款成功',
                  })
                }
              }
            })
          }
        }
      })
    }else{
      wx.navigateTo({
        url: '../../autonym/autonym?deposit=1',
      })
    }
  }
})