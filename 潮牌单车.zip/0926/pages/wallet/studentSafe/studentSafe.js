var app = getApp();
Page({
  data: {
    studentauth:'',
    conditionName:true,
    conditionStudent: true
  },
  menusCode(){
    if (this.data.conditionStudent){
      wx.navigateTo({
        url: '../../studentAutonym/studentAutonym',
      })
    }
  },
  menus(){
    if (this.data.conditionName) {
      wx.navigateTo({
        url: '../../autonym/autonym',
      })
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function () {
    var that = this;
    console.log(wx.getStorageSync('card'))
    if (wx.getStorageSync('card')==2){
      that.setData({
        conditionName: false
      })
    }
    if (wx.getStorageSync('studentauth')== 1) {
      that.setData({
        conditionStudent: false
      })
    }
  }
})