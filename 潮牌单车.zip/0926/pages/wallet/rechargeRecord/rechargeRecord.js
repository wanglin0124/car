var app = getApp();
Page({
  data: {
    array: '',
    newTime: ''
  },
  onLoad: function (options) {
    //我的行程记录
    var that = this;
    var userTransaction = 'App/V1/Userinfo/userTransaction';
    wx.request({
      url: app.globalData.getcode + userTransaction,
      data: {
        user_id: wx.getStorageSync('user_id'),
        token: wx.getStorageSync('token'),
        page: 1,
        type:1
      },
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded ' // 默认值
      },
      success: function (res) {
        console.log(res.data.data);
        var array = res.data.data;
        var day = '';
        var d = new Date().getDate();
        array.forEach(function (item) {
          var order=item.order_sn.substr(item.order_sn.length-18)
          day = order.slice(6, 8);
          if (order.slice())
          // if (Number(d) - Number(day) == 0) {
          //   item['day'] = '今天'
          // } else if (Number(d) - Number(day) == 1) {
          //   item['day'] = '昨天'
          // } else {
            item['day'] = order.slice(4, 6) + '.' + order.slice(6,8);
          // }
          item['time'] = order.slice(8, 10) + ':' + order.slice(10, 12);
        })
        // console.log(array)
        that.setData({
          array: array,
          newTime: new Date().getFullYear() + '年' + new Date().getMonth() + 1 + '月'
        })
      },
      fail: function () {
        console.log(res)
      }
    })
  }
})