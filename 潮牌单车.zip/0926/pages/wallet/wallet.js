var app = getApp();
Page({
  data: {
    balance:'0.00',
    deposit:'0.00',
    yearCard:'none',
    studentSafe:true
  },
  //去充值
  recharge:function(){
    wx.navigateTo({
      url: 'recharge/recharge'
    })
  },
  menusCode:function(){
    wx.navigateTo({
      url: 'rechargeRecord/rechargeRecord',
    })
  },
  menus:function(){
    if (wx.getStorageSync('deposit')>0) {
      wx.navigateTo({
        url: 'deposit/deposit?deposit=' + this.data.deposit
      })
    }
  },
  //年卡
  yearCaed(){
    wx.navigateTo({
      url: 'yearCard/yearCard?member=' + this.data.member,
    })
    // if (wx.getStorageSync('deposit') == 0){
    //   wx.showToast({
    //     title: '请先交纳押金',
    //     icon: 'loading',
    //     duration: 800
    //   })
    // }else{
    //   wx.navigateTo({
    //     url: 'yearCard/yearCard?member=' + this.data.day,
    //   })
    // }
  },
  //我的认证
  studentSafe(){ 
      wx.navigateTo({
        url: 'studentSafe/studentSafe' 
      })
  },
  result:function(){
    wx.showModal({
      title: '提示',
      content: '确认退出登录?',
      success: function (res) {
        if (res.confirm) {
          wx.clearStorageSync()
          wx.reLaunch({
            url: '../login/login'
          })
        }
      }
    })
    
  },
  onLoad: function (options) {

  },
  onShow(){
    var that=this;
    var userMoney = 'App/V1/Userinfomation/userMoney';
    wx.request({
      url: app.globalData.getcode + userMoney,
      data: {
        token: wx.getStorageSync('token'),
        user_id: wx.getStorageSync('user_id')
      },
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded '
      },
      success: function (res) {
        console.log(res.data)
        if (res.data.code == '0') {
          that.setData({
            balance: res.data.data.money,
            deposit: res.data.data.deposit +'元',
            day: res.data.data.member
          })
          console.log(res.data.data.deposit)
          if (wx.getStorageSync('studentauth') == 1 && res.data.data.deposit==0){
            console.log(res.data.data.deposit)
            that.setData({
              deposit: '学生认证免交押金',
            })
          }
          if (wx.getStorageSync('studentauth') == 1){
            that.setData({
              studentSafe: false,
            })
          }
          if (res.data.data.member > 0) {
            that.setData({
              member: res.data.data.member,
              day: res.data.data.member + '天',
            })
          } else {
            that.setData({
              day: '抢购校园卡',
              member: res.data.data.member
            })
          }
        }
      },
      fail: function (res) {
        console.log(res)
      }
    })
    if (!wx.getStorageSync('token')) {
      setTimeout(function () {
        wx.navigateTo({
          url: '../login/login',
        })
      }, 1000)
    }
    if (wx.getStorageSync('studentauth')=='1'){
        that.setData({
          yearCard: 'block'
        })
    }
  }
})