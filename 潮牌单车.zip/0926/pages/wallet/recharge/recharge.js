var app = getApp();
Page({
  data: {
    approveImg: '../../../img/btn_recharge_tick_nor.png',
    money:'0.00',  
    clicktag: '0',  
    array: [],
    array2: [
      {
        id: 0, message: '30元', image: '../../../img/btn_recharge_coin_nor.png',
      }, {
        id: 1, message: '60元', image: '../../../img/btn_recharge_coin_nor.png',
      },
      {
        id: 2, message: '90元', image: '../../../img/btn_recharge_coin_nor.png'
      }
    ],
    array1:[
      {
        id: 0, message: '20元', image: '../../../img/btn_recharge_coin_nor.png',
      }, {
        id: 1, message: '50元', image: '../../../img/btn_recharge_coin_nor.png',
      },
      {
        id: 2, message: '100元', image: '../../../img/btn_recharge_coin_nor.png'
      }
    ] 
  },
  onLoad: function () {
    if (wx.getStorageSync('studentauth')==1){
      this.setData({
        array:this.data.array1,
        money: this.data.array1[0].message,
        'array1[0].image':'../../../img/btn_recharge_coin_press.png'
      })
    }else{
      this.setData({
        array: this.data.array2,
        money: this.data.array2[0].message,
        'array2[0].image': '../../../img/btn_recharge_coin_press.png'
      })
    }
  },
  changeColor: function (event) {
    var that = this;
    var id = event.currentTarget.dataset.id;
    var arr=new Array();
    for(var i=0;i<that.data.array.length;++i){
      if(id==that.data.array[i].id){
        that.data.array[i].image = '../../../img/btn_recharge_coin_press.png'
      }else{
        that.data.array[i].image = '../../../img/btn_recharge_coin_nor.png'
      }
      arr.push(that.data.array[i])
    }
    that.setData({
     array:arr,
     money: event.currentTarget.dataset.message
    })
  },
  // 支付
  imageButton: function () {
    var that = this;
    that.setData({
      approveImg: '../../../img/btn_recharge_tick_press.png',
    })
  },
  affirm:function(){
    var that = this;
    var money = parseInt(that.data.money);
    if (money==0){
      wx.showModal({
        title: '提示',
        content: '请选择充值金额!',
        showCancel: false
      })
    }else{
      console.log(that.data.clicktag)
      if (that.data.clicktag == 0) {
        that.setData({
          clicktag: 1
        })
        setTimeout(function () {
          that.setData({
            clicktag: 0
          })
        }, 2000);
        var wechatApi = 'App/X1/Wxinfo/userPay';
        wx.request({
          url: app.globalData.getcode + wechatApi,
          data: {
            token: wx.getStorageSync('token'),
            user_id: wx.getStorageSync('user_id'),
            openid: wx.getStorageSync('openid'),
            price: money,
            type: 1
          },
          method: 'POST',
          header: {
            'content-type': 'application/x-www-form-urlencoded '
          },
          success: function (res) {
            console.log(res.data);
            if (res.data.code == 0) {
              console.log(res.data.data);
              var obj = JSON.parse(res.data.data)
              console.log(obj.appId)
              wx.requestPayment({
                'timeStamp': obj.timeStamp,
                'nonceStr': obj.nonceStr,
                'package': obj.package,
                'signType': 'MD5',
                'paySign': obj.paySign,
                success: function (res) {
                  console.log(res);
                  wx.reLaunch({
                    url: '../../map/map',
                  })
                }
              })
            }

          },
          fail: function (res) {
            console.log(res)
          }
        })
      }
    }

  }  
})