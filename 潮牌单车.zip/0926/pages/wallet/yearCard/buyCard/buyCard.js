var app = getApp();
Page({
  data: {
    money: '15',
    day:'30天',
    clicktag: '0',
    array:[]
  },
  onLoad: function () {
    var that = this;
    var memberShip ='App/V1/Activity/memberShip' ;
    wx.request({
      url: app.globalData.getcode + memberShip,
      header: {
        'content-type': 'application/x-www-form-urlencoded ',
      },
      success: function (res) {
        console.log(res);
        var array1 = res.data.data
        for(var i = 0; i < array1.length; i++) {
          array1[i].bgd = '../../../../img/btn_recharge_coin_nor1.png',
          array1[0].bgd ='../../../../img/btn_recharge_coin_press1.png'
        }
        that.setData({
          array: array1,
        })
      }
    })
  },
  changeColor: function (event) {
    var that = this;
    var id = event.currentTarget.dataset.id;
    console.log(event)
    var arr = new Array();
    for (var i = 0; i < that.data.array.length; ++i) {
      if (id == that.data.array[i].century) {
        that.data.array[i].bgd = '../../../../img/btn_recharge_coin_press1.png';
      } else {
        that.data.array[i].bgd = '../../../../img/btn_recharge_coin_nor1.png'
      }
      arr.push(that.data.array[i])
    }
    that.setData({
      array: arr,
      money: event.currentTarget.dataset.money,
    });

  },
  affirm: function () {
    var that = this;
    var money = parseFloat(that.data.money);
    console.log(money)
    if (money == 0) {
      wx.showModal({
        title: '提示',
        content: '请选择充值金额!',
        showCancel: false
      })
    } else {
      if (that.data.clicktag == 0) {
        that.setData({
          clicktag: 1
        })
        setTimeout(function () {
          that.setData({
            clicktag: 0
          })
        }, 2000);
        var wechatApi = 'App/X1/Wxinfo/userPay';
        wx.request({
          url: app.globalData.getcode + wechatApi,
          data: {
            token: wx.getStorageSync('token'),
            user_id: wx.getStorageSync('user_id'),
            openid: wx.getStorageSync('openid'),
            price: money,
            type: 4
          },
          method: 'POST',
          header: {
            'content-type': 'application/x-www-form-urlencoded '
          },
          success: function (res) {
            console.log(res.data);
            if (res.data.code == 0) {
              console.log(res.data.data);
              var obj = JSON.parse(res.data.data)
              console.log(obj.appId)
              wx.requestPayment({
                'timeStamp': obj.timeStamp,
                'nonceStr': obj.nonceStr,
                'package': obj.package,
                'signType': 'MD5',
                'paySign': obj.paySign,
                success: function (res) {
                  console.log(res);
                  wx.navigateBack({
                    delta:2
                  })
                },
                fail: function (res) {
                }
              })
            }

          },
          fail: function (res) {
            console.log(res)
          }
        })
      }
    }
  }
})