// pages/wallet/yearCard/yearCard.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    member:0,
  },
  onLoad(options){
    this.setData({
      member: options.member
    })
  },
  yearCard(){
    wx.navigateTo({
      url: '../../wallet/yearCard/buyCard/buyCard',
    })
  }
})