const app = getApp()
Page({
  data: {
    inputValue: '',//输入的手机号
    inputCode: '',//输入图片验证码
    backstage: '',//图片校验码
    misi: '',
    color: 'none',
    disabled: 'false',//禁用图片校验码
    focus: 'false',
    colorText:''
  },
  //输入手机号
  phoneTfInput: function (e) {
    var that = this;
    var inputValue = e.detail.value
    var length = e.detail.value.length;
    if (length == 11) {
      that.setData({
        inputValue: inputValue,
        disabled: '',
        focus: 'true'
      })
    }
  },
  //图形验证码
  codeTfInput(e) {
    var that = this;
    var inputCode = e.detail.value
    var length = e.detail.value.length;
    if (length == 4) {
      if ((/^1[34578]\d{9}$/.test(that.data.inputValue))) {
        var that = this;
        var userMessage = 'App/V1/Login/userMessage';
        wx.request({
          url: app.globalData.getcode + userMessage,
          data: {
            misi: that.data.misi,
            mobile: that.data.inputValue,
            code: inputCode
          },
          method: 'POST',
          header: {
            'content-type': 'application/x-www-form-urlencoded '
          },
          success: function (res) {
            // console.log(res);
            if (res.data.code == 1) {
              that.setData({
                color: 'block',
                colorText:res.data.info
              })
              that.userCheck()
            } else {
              that.setData({
                color: 'none'
              })
              wx.redirectTo({
                url: '../index/index?inputValue=' + that.data.inputValue+'&misi='+that.data.misi
              })
            }
          }
        })
      } else {
        wx.showModal({
          title: '提示',
          content: '手机号不正确',
          showCancel: false,
          success() {
            that.userCheck()
          }
        })
      }
    }
  },
  onLoad: function () {
    var that = this;
    wx.login({
      success: function (res) {
        var openid = res.code //微信给的,获取penid凭证
        that.setData({
          misi:res.code
        })  
        that.userCheck()
      }
    })
    //调用API从本地缓存中获取数据
    wx.getSystemInfo({
      success: function (res) {
        var kScreenW = res.windowWidth / 375;
        var kScreenH = res.windowHeight / 603;
        wx.setStorageSync('kScreenW', kScreenW)
        wx.setStorageSync('kScreenH', kScreenH)
        wx.setStorageSync('Height', res.windowHeight);
      }
    })
  },
  userCheck(){
    var that = this;
    var userCheck = 'App/V1/Login/userCheck';
    wx.request({
      url: app.globalData.getcode + userCheck,
      data: { misi: that.data.misi },
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded '
      },
      success: function (res) {
        // console.log(res)
        that.setData({
          backstage: res.data.data.image
        })
      },
      fail(){
        console.log(res)
      }
    })
  
  }
})
