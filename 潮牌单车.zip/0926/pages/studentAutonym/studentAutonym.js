var app = getApp();
Page({
  data: {
    // 点击按钮
    proceed: 'proceed',
    proceed1: '',
    proceed2: '',
    // 页面切换
    change: 'block',
    change1: 'none',
    change2: 'none',
    common: 'blcok',
    card: '',//身份证号
    username: '',//用户名
    array:'',
    index:0,
    studentName:'', //学生真实姓名
    studentauth:'',   //学号
    school_id:'1'   //学校id
  },
  onLoad: function () {
    this.setData({
      proceed: '',
      proceed1: 'proceed',
      change: 'none',
      change1: 'block',
      common: 'none',
    });
    if (wx.getStorageSync('studentauth') =='2'){
     this.setData({
       proceed: '',
       proceed1: 'proceed',
       change: 'none',
       change1: 'block',
       common: 'none',
     });
   }
    var that = this;
    var wechatApi = 'App/V1/Students/schoolInfo';
    wx.request({
      url: app.globalData.getcode + wechatApi,
      data: {
        token: wx.getStorageSync('token'),
        user_id: wx.getStorageSync('user_id'),
      },
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded '
      },
      success: function (res) {
        that.setData({
          array:res.data.data
        })
      }
    })
  },
  bindPickerChange: function (e) {
    var that = this;
    console.log('picker发送选择改变，携带值为', e.detail.value);
    this.setData({
      index: e.detail.value,
      school_id: that.data.array[e.detail.value].id
    })
    console.log(that.data.school_id)
  },
  idName(e) {
    var that = this;
    that.setData({
      username: e.detail.value
    })
  },
  idNumber: function (e) {
    var that = this;
    that.setData({
      card: e.detail.value
    })
  },
  // 提交资料
  login: function () {
    var that = this;
    if ((/^[1-9]\d{7}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}$|^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}([0-9]|X)$/.test(that.data.card))) {
      var that = this;
      var userCard = 'App/V1/Userinfo/userCard';
      wx.request({
        url: app.globalData.getcode + userCard,
        data: {
          user_id: wx.getStorageSync('user_id'),
          token: wx.getStorageSync('token'),
          username: that.data.username,
          card: that.data.card,
        },
        method: 'POST',
        header: {
          'content-type': 'application/x-www-form-urlencoded '
        },
        success: function (res) {
          console.log(res.data)
          var statu = res.data.code
          if (statu == '0') {
            wx.showToast({
              title: '发送成功',
              icon: 'success',
              duration: 2000,
            })
            that.setData({
              proceed: '',
              proceed1: 'proceed',
              change: 'none',
              change1: 'block',
              common: 'none',
            });
            wx.setStorageSync('studentauth', 1);
            wx.setNavigationBarTitle({
              title: '押金充值'
            })
          } else {
            wx.showModal({
              title: '提示',
              content: res.data.info,
            })
          }
        }
      })

    } else if (!that.data.card) {
      wx.showModal({
        title: '提示',
        content: '身份证号不能为空!',
        showCancel: false
      })
    } else {
      wx.showModal({
        title: '提示',
        content: '身份证号错误!',
        showCancel: false
      })
    }
  },
  studentName(e){
    var that = this;
    that.setData({
      studentName: e.detail.value
    })
  },
  studentauth(e){
    var that = this;
    that.setData({
      studentauth: e.detail.value
    })
  },
  // 上传学生认证信息
  affirm: function () {
    var that = this;
    var wechatApi = 'App/V1/Students/studentInfo';
    wx.request({
      url: app.globalData.getcode + wechatApi,
      data: {
        token: wx.getStorageSync('token'),
        user_id: wx.getStorageSync('user_id'),
        username:that.data.studentName, //真实姓名
        studentauth: that.data.studentauth,    //学号
        school_id: that.data.school_id     //学校

      },
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded '
      },
      success: function (res) {
        console.log(res.data)
        if (res.data.code == 0) {
          that.setData({
            proceed1: '',
            proceed2: 'proceed',
            change1: 'none',
            change2: 'block',
            common: 'none',
          });
          wx.setStorageSync('studentauth', '1')
          wx.showToast({
            title: '认证成功!',
          })
          wx.setNavigationBarTitle({
            title: '完成'
          })   
        }else{
          wx.showModal({
            title: '提示',
            content: res.data.info,
            showCancel:false
          })
        }
      }
    })

  },
  // 充值
  recharge: function () {
    wx.navigateTo({
      url: '../wallet/recharge/recharge'
    })
  },
  // 立即体验
  experience: function () {
    wx.navigateTo({
      url: '../wallet/yearCard/yearCard'
    })
  }
})
