const app = getApp();
var QQMapWX = require('../../utils/qqmap-wx-jssdk.min.js');
//获取应用实例
Page({
  data: {
    doubt:true,
    tripOne:false,
    mobile:'共享车位',//用户昵称
    timenoteinfo:'',//正常时间段
    id:'',
    lockAdress: true,//共同函数address() 作为判断是开锁吗
    yuyue:false,//共同函数address() 作为判断是预约吗
    // 蓝牙开锁-------------------------
    // lock:'',//开锁关锁的指令
    // writeDataUUID:'',//写入UUId
    // services:'',//服务uuid
    // open:{},
    // dataOpen:[],
    // appointment:{},//地锁信息
    // 模态框
    // noteinfo:'',//锁的提示信息
    // time_solt: '',//禁止时间段
    // solt_price: '',//禁止时间段单价
    // paymentMoney:'',//用户余额
    //合并后的控件-------------------------------------------------------------
    trip:false,
    order: false,
    header: false,//调用微信扫描时出现
    // tripTime: false,//骑行中的时间表
    customer: false,//客服
    doubt: false,//疑问
    appoint: false,//预约
    distance:'0',//距离起始位置
    //地图样式--------------------------------------------------------------
    latitude: 0,  //用户当前位置
    longitude: 0,
    // controls: '', //地图上不可移动的控件
    baginMapControls: [    //刚开始地图组件
      //扫描二维码控件按钮
      {
        id: 1,
        iconPath: '../../img/ico_usebicycle.png',
        position: {
          left: wx.getStorageSync('kScreenW') * 105,
          top: wx.getStorageSync('kScreenH') * 510,
          width: wx.getStorageSync('kScreenW') *170,
          height: wx.getStorageSync('kScreenH') * 64,
        },
        clickable: true
      },
      //个人中心按钮
      {
        id: 2,
        iconPath: '../../img/imgs_main_user.png',
        position: {
          left: wx.getStorageSync('kScreenW') * 300,
          top: wx.getStorageSync('kScreenH') * 520,
          width: wx.getStorageSync('kScreenW') * 50,
          height: wx.getStorageSync('kScreenH') * 50,
        },
        clickable: true
      },
      // //地图中心位置按钮
      {
        id: 3,
        iconPath: '../../img/ico_point.png',
        position: {
          left: wx.getStorageSync('kScreenW') * 177,
          top: wx.getStorageSync('kScreenH') * 272,
          width: wx.getStorageSync('kScreenW') * 20,
          height: wx.getStorageSync('kScreenH') *75,
        },
        clickable: false,
      },
      //显示位置按钮
      {
        id: 4,
        iconPath: '../../img/imgs_main_location.png',
        position: {
          left: wx.getStorageSync('kScreenW') * 30,
          top: wx.getStorageSync('kScreenH') * 520,
          width: wx.getStorageSync('kScreenW') * 50,
          height: wx.getStorageSync('kScreenH') * 50,
        },
        clickable: true,
      }
    ],
    // markers: [],// 标记数组
    Height: wx.getStorageSync('Height'), //地图的高
    mapScale:12,
    numberShow:'',//展示到页面上
    time: '00:00:00',
    order_sn: '',//计算行车进行中有退出的z
    price: '0',   //为完成支付订单钱
    price1:'0',
    // headerTime:'',
    timerOne:0,
    timerTwo:0
  },
  //控件的点击事件
  controltap: function (e) {
    var that = this;
    var id = e.controlId
    if (id == 4) {
      //定位当前位置
      that.movetoPosition();
    } else if (id == 1) {
      wx.getNetworkType({
        success: function (res) {
          console.log(res)
          if (res.networkType == 'none') {
            wx.showToast({
              title: '无网络连接',
              icon: 'loading'
            })
          }else{
            that.scancode()
          }
        }
      })  
    } else if (id == 2) {
      wx.navigateTo({
        url: '../wallet/wallet'
      })
    }
  },
  map(){
    this.setData({
      appoint:false
    })
  },
  //点击markers触发
  markertap(e){
    var that=this;                  
    var open = e.target.dataset.open;
    for (var i = 0; i < open.length; i++) {
      if (e.markerId == i) {
        that.setData({
          open:
          {
            number: open[i].number
          }
        })
      }
    }
    var userBicycleType = '/api/v1/land/show'
    wx.request({
      url: app.globalData.getcode + userBicycleType,
      data: {
        userid: wx.getStorageSync('user_id'),
        number:that.data.open.number
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded',
        'token': wx.getStorageSync('token'),
      },
      success(res){
        console.log(res)
        if(res.data.code==0){
          var time_solt = res.data.data.time_solt;
          var left = parseFloat(time_solt.split('-')[0]);
          var right = parseFloat(time_solt.split('-')[1]);
          if (right > 24) {
            right = right - 24
          }
          var noteinfo = left + ':00-' + right + ':00'//禁用时段
          var timenoteinfo = right + ':00-' + left + ':00'
          if (right == 0) {
            var noteinfo = left + ':00-24:00'
            var timenoteinfo = '24:00-' + left + ':00'
          }
          // if (Number(left) - 1 == 0) {
          //   var timenoteinfo = (right + 1) + ':00-24:00'
          // } else {
          //   var timenoteinfo = (right+ 1) + ':00-' + (left - 1 + ':00')
          // }
          var numberShow = res.data.data.number.substr(res.data.data.number.length - 5)
          that.setData({
            numberShow: '***' + numberShow,
            appoint: true,
            'open.price': Number(res.data.data.price),
            'open.latitude': res.data.data.latitude,
            'open.longitude': res.data.data.longitude,
            'solt_price': Number(res.data.data.solt_price),
            noteinfo: noteinfo,
            timenoteinfo: timenoteinfo
          })
          // 实例化API核心类
          var demo = new QQMapWX({
            key: 'DJPBZ-VMVWO-P3SWK-ST2YU-WGHBQ-27BXS' // 必填
          });
          // 调用接口
          demo.reverseGeocoder({
            location: {
              latitude: res.data.data.latitude,
              longitude: res.data.data.longitude
            },
            success: function (res) {
              var address = res.result.address_component.city + res.result.formatted_addresses.recommend;
              that.setData({
                'open.address': address
              })
            },
            fail: function (res) {
              console.log(res);
            }
          });
          // 调用接口计算距离
          demo.calculateDistance({
            mode: 'driving',
            to: [{
              latitude: res.data.data.latitude,
              longitude: res.data.data.longitude
            }],
            success: function (res) {
              var distance = res.result.elements[0].distance
              if (parseInt(distance) >= 1000) {
                distance = Math.round(distance / 1000 * Math.pow(10, 1)) / Math.pow(10, 1) + 'km'
              } else {
                distance = distance + "m"
              }
              that.setData({
                distance: distance
              })
            },
            fail: function (res) {
              console.log(res);
            }
          });
        }else{
          that.setData({
            appoint:false
          })
          wx.showModal({
            title: '提示',
            content: res.data.info,
            showCancel:false
          });
        }
      }
    })
  },
  //导航
  navigation(){
    var that=this; 
    wx.openLocation({
      latitude: Number(that.data.open.latitude),
      longitude: Number(that.data.open.longitude),
      address:that.data.open.address,
      scale: 28
    })
  },
  //点击预约
  appointment() {
    var that = this;
    if (that.data.paymentMoney < 0 && that.data.merchant!=2) {
      wx.showModal({
        title: '提示!',
        content: '您的账户没有余额,充值后可立即使用!',
        confirmText: '充值',
        success: function (res) {
          console.log(res.confirm);
          if (res.confirm) {
            wx.navigateTo({
              url: '../wallet/recharge/recharge',
            })
          }
        }
      })
    } else {
      that.setData({
        yuyue: true,
        lockAdress:false
      })
      that.address();
    }
  },
  // 确认预约--取消
  trueAppoint() {
    this.setData({
      status:4,
    })
    this.unlock()
  },
  //开锁
  unlocking: function () {
    this.setData({
      status: 0
    })
    this.unlock()
  },
  unlock(){ 
    var that = this;
    var userUnlock = '/api/v1/unlock';
    wx.request({
      url: app.globalData.getcode + userUnlock,
      data: {
        userid: wx.getStorageSync('user_id'),
        number: that.data.open.number,
        order_way: 3,
        status: that.data.status,
        battery_level: that.data.battery_level
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded',
        'token': wx.getStorageSync('token')
      },
      success: function (res) {
        console.log(res, '开锁后信息');
        if (res.data.code == 0) {
          if (res.data.data.order_sn) {
            that.setData({
              order_sn: res.data.data.order_sn
            })
          }
          if(that.data.lock=='0x03'){
            that.writeBLECharacteristicValue();
          }else{
            that.order()
          }
        } else {
          wx.showModal({
            title: '提示',
            content: res.data.info,
            showCancel: true,
            success() {
              that.setData({
                controls: baginMapControls,
              })
              that.getBikeList(that.data.latitude, that.data.longitude)
            }
          })
        }
      },
      fail: function (res) {
        console.log(res)
      }
    })
  },
  // 扫码开锁
  address(){
    var that = this;
    var userBicycleType = '/api/v1/land/show'
    wx.request({
      url: app.globalData.getcode + userBicycleType,
      data: {
        userid: wx.getStorageSync('user_id'),
        number: that.data.open.number,
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded',
        'token': wx.getStorageSync('token')
      },
      success: function (res) {
        console.log(res);
        if (res.data.code == 1) {
          wx.showModal({
            title: '提示',
            content: res.data.info,
            showCancel: false,
          })
          that.setData({
            controls: that.data.baginMapControls
          })
          wx.setNavigationBarTitle({
            title: '潮牌共享停车'
          })
          that.getBikeList(that.data.latitude, that.data.longitude)
        } else if (res.data.code == 0){
          //不是商户的锁,余额小于0
          if (res.data.data.vip == 1 && that.data.paymentMoney <0 ){
            wx.showModal({
              title: '提示!',
              content: '您的账户没有余额,充值后可立即使用!',
              confirmText: '充值',
              success: function (res) {
                console.log(res.confirm);
                if (res.confirm) {
                  wx.navigateTo({
                    url: '../wallet/recharge/recharge',
                  })
                }
              }
            })
          }else{
            if (that.data.lockAdress) {
              wx.showToast({
                title: '开锁中',
                icon: 'loading',
                mask: true,
                duration: 15000
              })
              that.setData({
                lockAdress:true
              })
              if (wx.openBluetoothAdapter) {
                that.startConnect()
              } else {
                wx.showModal({
                  title: '提示',
                  content: '当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。'
                })
              }
            } else if (that.data.yuyue){
              wx.showModal({
                title: '提示',
                content: '预约成功即开始计费,您确定要预约吗?',
                confirmText: '确定预约',
                success(res) {
                  if (res.confirm) {
                    that.setData({
                      appoint: true,
                      yuyue: false
                    })
                    that.trueAppoint();
                  }
                }
              })
            }
            if (that.data.appoint) {
              that.setData({
                header: false
              })
            } else {
              that.setData({
                header: true,
                controls: ''
              })
            }
            var time_solt = res.data.data.time_solt;
            var left = parseFloat(time_solt.split('-')[0]);
            var right = parseFloat(time_solt.split('-')[1]);
            if (right > 24) {
              right = right - 24
            }
            var noteinfo = left + ':00-' + right + ':00'//禁用时段
            var timenoteinfo = right + ':00-' + left + ':00'
            if (right == 0) {
              var noteinfo = left + ':00-24:00'
              var timenoteinfo = '24:00-' + left + ':00'
            }

            var numberShow = res.data.data.number.substr(res.data.data.number.length - 5)
            that.setData({
              numberShow: '***' + numberShow,
              appointment: {//蓝牙开锁,预约所需参数
                address: res.data.data.address,
                bluemac: res.data.data.bluemac
              },
              markers: '',
              price: res.data.data.price,
              'open.price': Number(res.data.data.price),
              'solt_price': Number(res.data.data.solt_price),
              noteinfo: noteinfo,
              timenoteinfo: timenoteinfo
            })
            // 实例化API核心类
            var demo = new QQMapWX({
              key: 'DJPBZ-VMVWO-P3SWK-ST2YU-WGHBQ-27BXS' // 必填
            });
            // 调用接口
            demo.reverseGeocoder({
              location: {
                latitude: res.data.data.latitude,
                longitude: res.data.data.longitude
              },
              success: function (res) {
                var address = res.result.address_component.city + res.result.formatted_addresses.recommend;
                that.setData({
                  'open.address': address
                })
              },
              fail: function (res) {
                console.log(res);
              }
            });
          }
        }
      }
    })
  },                       
  //扫描二维码 
  scancode:function(){
    var that=this;
    if (that.data.paymentMoney < 0 && that.data.merchant != 2) {
      wx.showModal({
        title: '提示!',
        content: '您的账户没有余额,充值后可立即使用!',
        confirmText: '充值',
        success: function (res) {
          console.log(res.confirm);
          if (res.confirm) {
            wx.navigateTo({
              url: '../wallet/recharge/recharge',
            })
          } 
        }
      })
    } else{
      wx.scanCode({
        success: function (res) {
          var number = res.result.match(/[=](\S*)/)[1];//地锁number
          that.setData({
            'open.number': number,
            mapScale: 16,
            customer: false,
            appoint: false,
            lockAdress:false,
          });
          wx.setNavigationBarTitle({
            title: '扫码解锁'
          })
          that.address()
        },
        fail: function () {
          wx.showToast({
            title: '扫码失败',
            icon: 'loading',
            duration: 2000,
          })
        }
      })
    }
  },
  //点击立即用车,开锁
  scanBikeQr:function(){
    var that=this;
    that.setData({
      lockAdress: true,
      id:''
    })
    if (that.data.paymentMoney < 0 && that.data.merchant != 2) {
        wx.showModal({
          title: '提示!',
          content: '您的账户没有余额,充值后可立即使用!',
          confirmText: '充值',
          success: function (res) {
            console.log(res.confirm);
            if (res.confirm) {
              wx.navigateTo({
                url: '../wallet/recharge/recharge?id=' + wx.getStorageSync('id'),
              })
            }
          }
        })
      } else {
        wx.setStorageSync('id', '');
        if (that.data.flagUlock==4){
          this.setData({
            lock: '0x03'//开 
          })
          wx.showToast({
            title: '开锁中',
            icon: 'loading',
            mask: true,
            duration: 10000
          })
          if (wx.openBluetoothAdapter) {
            that.startConnect()
          } else {
            wx.showModal({
              title: '提示',
              content: '当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。'
            })
          }
        }else{
          this.setData({
            lock: '0x03'//开 
          })
          that.address()
        }
      }
  
  },
  userCenter(){
    var that = this;
    var userMoney = '/api/v1/userinfo';
    wx.request({
      url: app.globalData.getcode + userMoney,
      data: {
        type: 1,
        userid: wx.getStorageSync('user_id')
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded',
        'token': wx.getStorageSync('token')
      },
      success: function (res) {
        console.log(res);
        that.setData({
          mobile: res.data.data.nickname,
          merchant: res.data.data.merchant
        })
        if (res.data.data.images==''){
          that.setData({
            images:'../../img/profilephoto.png'
          })
        }else{
          that.setData({
            images: res.data.data.images
          })
        }
      },
      fail: function (res) {
        console.log(res)
      }
    })
  },
  //取消预约
  cancellation() {
    var that = this;
    wx.showModal({
      title: '提示!',
      content: ' 您确定取消预约吗?',
      confirmText: '确定',
      success(res) {
        if (res.confirm) {
          that.endOrder()
        }
      }
    })
  },
  //蓝牙关闭地锁（或者结束订单）
  endOrder(){
    var that = this;
    console.log(that.data.battery_level + "关锁电量34234134234")
    var userBicycleType = '/api/v1/unlock'
    wx.request({
      url: app.globalData.getcode + userBicycleType,
      data: {
        userid: wx.getStorageSync('user_id'),
        order_sn: that.data.open.order_sn,
        number: that.data.open.number,
        online: 2,
        battery_level: that.data.battery_level
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded',
        'token': wx.getStorageSync('token'),
      },
      method: 'POST',
      success: function (res) {
        console.log(res, '关闭地锁');
          wx.setNavigationBarTitle({
            title: '潮牌共享停车'
          })
          that.setData({
            customer: false,
            header:false,
            controls: that.data.baginMapControls,
            // tripTime: false,
            trip: false,
            tripOne: false,
            time:'00.00.00',
            timerOne: 0,
            timerTwo: 0,
            trip:false,
            tripOne:false
          })
          clearInterval(that.timerTwo);
          clearInterval(that.timerOne);
          clearInterval(that.ridingTimer);
          that.getBikeList(that.data.latitude, that.data.longitude)
        }
    })
  },
  gameOver(){
    var that=this;
    wx.showModal({
      title: '提示',
      content: '请确认您已驶离车位，再结束订单!',
      success(res){
        if (res.confirm){
          wx.getNetworkType({
            success: function (res) {
              console.log(res)
              if (res.networkType == 'none') {
                wx.showToast({
                  title: '无网络连接',
                  icon: 'loading'
                })
              } else {
                that.orderland();
                // that.endOrder()
              // that.startConnect();
              }
            }
          })  
        }
      }
    })
  },
  orderland(){
    var that = this;
    var userBicycleType = '/api/v1/land/create';
    wx.request({
      url: app.globalData.getcode + userBicycleType,
      data: {
        userid: wx.getStorageSync('user_id'),
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded',
        'token': wx.getStorageSync('token')
      },
      success: function (res) {
        console.log(res)
        if(res.data.code==0){
          that.setData({
            lock: '0x05',//关锁
          })
          console.log(that.data.lock);
          wx.getBluetoothAdapterState({
            success: function (res) {
              console.log('关锁写入');
              wx.showToast({
                title: '关锁中',
                icon: 'loading',
                mask: true,
                duration: 10000
              })
              var available = res.available;//蓝牙适配器是否可用
              console.log(available,'蓝牙适配器是否可用')
              if (available) {
                that.writeElectricity()
              }else{
                that.startConnect()
              }
            },
            fail: function () {
              wx.showToast({
                title: '关锁中',
                icon: 'loading',
                mask: true,
                duration: 10000
              })
              that.startConnect()
            }
          })
        } else if(res.data.code==1){
          wx.setNavigationBarTitle({
            title: '潮牌共享停车'
          })
          that.setData({
            customer: false,
            controls: that.data.baginMapControls,
            // tripTime: false,
            trip: false,
            tripOne: false,
            time: '00.00.00'
          })
          clearInterval(that.timerTwo);
          clearInterval(that.timerOne);
          clearInterval(that.ridingTimer);
          that.getBikeList(that.data.latitude, that.data.longitude)
        }
      }
    })
  },
  //取消用车
  cancel:function(){
    this.setData({
      controls: this.data.baginMapControls,
      header: false,
      id:''
    })
    wx.setNavigationBarTitle({
      title: '潮牌共享停车'
    })
    wx.setStorageSync('id', '')
    this.getBikeList(this.data.latitude, this.data.longitude)
    this.movetoPosition();
    
  },
  // 地图视野改变事件
  bindregionchange: function (e) {
    var that = this; 
    if (that.data.trip == false || that.data.tripOne == false) {//如果在进行时就不会刷新单车&&扫描二维码时同样
      that.mapCtx.getCenterLocation({
        success: function (res) {
          if(e.type == "end") {// 停止拖动，显示单车位置       
            that.getBikeList(res.latitude, res.longitude);//查询附近车辆,与正在进行中的订单
          }
        }
      })
    }
  },
  //请求附近单车列表
  getBikeList: function (latitude,longitude) {
    var that = this;
    var equipmentIndex = '/api/v1/land'
    wx.request({
      url: app.globalData.getcode + equipmentIndex,
      data: {
        userid: wx.getStorageSync('user_id'),
        longitude:longitude,
        latitude: latitude,
        type: 2
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded',
        'token': wx.getStorageSync('token'),
      },
      success: function (res) {
        console.log('附近地锁列表')
        console.log(res)
        if (res.data.code == 0) {
          var iconPath = '../../img/ico_landmark_parkinglock.png';
          var bikeArr = res.data.data;
          //附近地锁
          var markers = [];
          var markers1=[];
          if(bikeArr.length>40){//最多只返回40辆
            for (var i = 0; i <= 40; ++i) {
              var marker = {
                latitude: Number(bikeArr[i].latitude),
                longitude: Number(bikeArr[i].longitude),
                iconPath: iconPath,
                id: i,
                width: 36,
                height: 40
              }
              var dataOpen = {//得到车位信息
                number: item.number,
              }
              markers1.push(dataOpen)//车位信息压入数组
              markers.push(marker)
            }
          }else{//小于40辆的显示
            bikeArr.forEach(function (item, index) {
            var marker = {
              latitude: Number(item.latitude),
              longitude: Number(item.longitude),
              iconPath: iconPath,
              id: index,
              width: 50,
              height:50
            }
            var dataOpen={//得到车位信息
              number:item.number,
            }
            markers1.push(dataOpen)//车位信息压入数组
            markers.push(marker)
          })
          } 
          if (that.data.header || that.data.trip || that.data.tripOne) {
            that.setData({
              markers: '',
              controls: '',
            })
          }else{
            that.setData({
              markers: markers,
              dataOpen: markers1,
              controls: that.data.baginMapControls,
            })    
          }
        }
      },
      fail: function (res) {
        console.log(res)
      }
    })
  },
  // 定位函数，移动位置到地图中心
  movetoPosition: function () {
    var that = this
    that.mapCtx.moveToLocation();
    that.setData({
      mapScale: 16,
    })  
  },
  //轮询是否关锁
  userLock:function(){         
    var that=this; 
    var userLock = '/api/v1/motion';
    wx.request({
      url: app.globalData.getcode + userLock,
      data: {
        userid: wx.getStorageSync('user_id'),
        start_time: that.data.start_time,
        price: that.data.price1,
        time_long: that.data.headerTime,
        time_solt: that.data.time_solt,
        solt_price: that.data.solt_price,
        number: that.data.open.number
      },
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded',
        'token': wx.getStorageSync('token'),
      },
      success: function (res) {
        console.log(res);
        if (res.data.code == 304) {
          clearInterval(that.timerTwo);
          clearInterval(that.timerOne);
          clearInterval(that.ridingTimer);
          that.setData({
            customer: false,
            header: false,
            controls: that.data.baginMapControls,
            // tripTime: false,
            trip:false,
            tripOne:false,
            time: '00.00.00',
            timerOne: 0,
            timerTwo: 0
          })
          wx.showModal({
            title: '提示',
            content: res.data.info,
            showCancel:false,
            success(){
              wx.navigateTo({
                url: '../index/index'
              })
            }
          })
        }else if (res.data.code==0){
          // wx.removeStorageSync('number')
          var price = String(res.data.data.prices)
          if (price.indexOf('.') != -1) {
            that.setData({
              price: price,
            })
          } else {
            that.setData({
              price: price,
            })
          }
        } else if (res.data.code == 3) {
          // wx.showToast({
          //   title: '3'
          // })
          wx.setNavigationBarTitle({
            title: '潮牌共享停车'
          })
          wx.closeBLEConnection({
            deviceId: that.data.deviceId,
            success: function (res) {
              console.log(res);
              that.setData({
                deviceId: ''
              })
              wx.closeBluetoothAdapter({
                success: function (res) {
                  console.log(res);
                }
              })
            }
          })
          that.setData({
            customer: false,
            header: false,
            controls: that.data.baginMapControls,
            // tripTime: false,
            trip: false,
            tripOne: false,
            time: '00.00.00',
            timerOne: 0,
            timerTwo: 0
          })
          clearInterval(that.timerTwo);
          clearInterval(that.timerOne);
          clearInterval(that.ridingTimer);
          that.getBikeList(that.data.latitude, that.data.longitude)
        } 
      }
    })
  },
  //客服电话
  customer:function(){
    var that=this;
    var userMoney = '/api/v1/show';
    wx.request({
      url: app.globalData.getcode + userMoney,
      data: {
        type: 1,
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        wx.makePhoneCall({
          phoneNumber: res.data.data[0].mobile
        })
      }
    })
  },
  //疑难解答+
  doubt:function(){
    wx.navigateTo({
      url: 'doubt/doubt',
    })
  },
  //查看余额
  paymentMoney: function () {
    var that = this;
    var userMoney = '/api/v1/userinfo';
    wx.request({
      url: app.globalData.getcode + userMoney,
      data: {
        type: 2,
        userid: wx.getStorageSync('user_id')
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded',
        'token': wx.getStorageSync('token')
      },
      success: function (res) {
        that.setData({
          paymentMoney: parseInt(res.data.data.money)
        })
        if(res.data.code==304) {
          clearInterval(that.timerTwo);
          clearInterval(that.timerOne);
          clearInterval(that.ridingTimer);
          that.setData({
            customer: false,
            header: false,
            controls: that.data.baginMapControls,
            // tripTime: false,
            trip: false,
            tripOne: false,
            time: '00.00.00',
            timerOne: 0,
            timerTwo: 0
          })
          wx.showModal({
            title: '提示',
            content: res.data.info,
            showCancel: false,
            success() {
              wx.navigateTo({
                url: '../index/index'
              })
            }
          })
        }
      },
      fail: function (res) {
        console.log(res)
      }
    })
  },
  //查看是否有未完成的订单
  order: function () {
    var that = this;
    var userBicycleType = '/api/v1/land/create';
    wx.request({
      url: app.globalData.getcode + userBicycleType,
      data: {
        userid: wx.getStorageSync('user_id'),
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded',
        'token': wx.getStorageSync('token')
      },
      success: function (res) {
        console.log(res,'查看是否有未完成的订单')
        if (res.data.code == 0) {
          var newDate = res.data.data.order_sn;
          var time_long = newDate.slice(0, 4) + '年' + newDate.slice(4, 6) + '月' + newDate.slice(6, 8) + '日 ' + newDate.slice(8, 10) + '时' + newDate.slice(10, 12) + '分' + newDate.slice(12, 14) + '秒';
          var numberShow = res.data.data.number.substr(res.data.data.number.length - 5)
          that.setData({
            customer: true,
            appoint: false,
            header: false,
            controls: '',
            markers: '',
            // tripTime: false,
            price1: res.data.data.price,
            numberShow: '***' + numberShow,
            headerTime: res.data.data.time_long,
            start_time: res.data.data.start_time,
            time_solt: res.data.data.time_solt,
            solt_price: res.data.data.solt_price,
            'open.order_sn': res.data.data.order_sn,
            'appointment.bluemac': res.data.data.bluemac,
            'open.price': res.data.data.price,
            'open.number': res.data.data.number,
             order_sn:res.data.data.order_sn
          })
          that.userCenter();
          console.log(that.data.timerOne, that.data.timerTwo)
          if (that.data.timerOne == 0 && that.data.timerTwo == 0) {
            clearInterval(that.timerOne)
            clearInterval(that.ridingTimer);
            clearInterval(that.timerTwo);
            that.timerTwo = setInterval(function () {
              var time = res.data.data.start_time;//开始骑行的时间
              var now = parseInt(new Date().valueOf() / 1000);//当前时间戳	 	
              var date = now - time;
              var hour = Math.floor(date / 3600);
              var minute = Math.floor((date % 3600) / 60);
              var second = date % 60;
              if (second.toString().length == 1) {
                second = '0' + second
              }
              if (hour.toString().length == 1) {
                hour = '0' + hour
              }
              if (minute.toString().length == 1) {
                minute = '0' + minute
              }
              that.setData({
                time: hour + ":" + minute + ":" + second,
              })
              if (that.data.time.slice(3, 5) >= 30) {
                that.setData({
                  tripTime: true,
                })
              }
              console.log(that.data.time + 'two')
            }, 1000)
            that.setData({
              timerTwo: 1,
            })
            if (res.data.data.vip == 1) {
              that.setData({
                price: res.data.data.price,
              })
              that.userLock()
              that.ridingTimer = setInterval(function () {
                that.userLock()
              }, 5000)
            } else {
              that.setData({
                price: 0,
              })
            }
          }
          if (res.data.data.flag == 0) {
            // wx.removeStorageSync('number')
            that.setData({
              flagUlock: 0,
              tripOne:true,
              trip: false
            })
            wx.setNavigationBarTitle({
              title: '车位使用中'
            })
          } else if (res.data.data.flag == 4) {
            that.setData({
              flagUlock: 4,
              trip: true,
              tripOne: false
            })
            wx.setNavigationBarTitle({
              title: '车位预约中'
            })
          } else if(res.data.data.flag==3){
            that.setData({
              order:true,
              price: res.data.data.price,
              order_sn: res.data.data.order_sn,
            })
          }    
        } else if (res.data.code=1){
          if (that.data.id && wx.getStorageSync('user_id')){
              that.setData({
                'open.number': that.data.id,
                controls: '',
                lockAdress: false,
                id: ''
              });
              wx.setNavigationBarTitle({
                title: '扫码解锁'
              })
              that.address();    
          }else{
            that.getBikeList(that.data.latitude, that.data.longitude);
          }
        }
      }
    })
  },
  //有未完成订单去支付
  orderTap: function () {
    wx.navigateTo({
      url: '../payment/payment?price='+this.data.price+'&&order_sn='+this.data.order_sn,
    })
  },
  //调蓝牙
  startConnect: function () {
    var that = this;
    wx.openBluetoothAdapter({
      success: function (res) {
        console.log(res, '蓝牙初始化');
        that.getBluetoothAdapterState();
      },
      fail: function (err) {
        console.log(err);
        that.setData({
          lock: ''//开 
        })
        wx.closeBluetoothAdapter({
          success: function (res) {
            console.log(res)
          }
        })
        wx.showToast({
          title: '请打开蓝牙',
          image: '../../img/err.png',
        })
      }
    });
  },
  // 获取本机蓝牙适配器状态
  getBluetoothAdapterState: function () {
    var that = this;
    wx.getBluetoothAdapterState({
      success: function (res) {
        console.log(res, ' 获取本机蓝牙适配器状态')
        var available = res.available;//蓝牙适配器是否可用
        var discovering = res.discovering;//是否正在搜索设备
        if (!available) {
          wx.showToast({
            title: '设备无法开启蓝牙连接',
            icon: 'success',
            duration: 2000
          })
          setTimeout(function () {
            wx.hideToast()
          }, 2000)
        }else{
          that.startBluetoothDevicesDiscovery();
        }
      },
      fail: function () {
        wx.showToast({
          title: '蓝牙适配失败',
          image: '../../img/err.png',
          success() {
            wx.closeBluetoothAdapter({
              success: function (res) {
                console.log(res)
              }
            })
            that.setData({
              header: false,
              controls: that.data.baginMapControls
            })
          }
        })
      }
    })
  },
  //开始搜寻附近的蓝牙外围设备
  startBluetoothDevicesDiscovery: function () {
    var that = this;
    wx.startBluetoothDevicesDiscovery({
      services: [],
      success: function (res) {
        console.log(res, '开始搜寻附近的蓝牙外围设备')
        if (!res.isDiscovering) {//当前蓝牙适配器是否处于搜索状态
          that.getBluetoothAdapterState(); // 获取本机蓝牙适配器状态,返回上一个接口
        } else {
          that.onBluetoothDeviceFound();//监听寻找到新设备的事件
        }
      },
      fail: function (err) {
        console.log(err);
        wx.showToast({
          title: '蓝牙搜索失败',
          image: '../../img/err.png',
          success() {
            wx.stopBluetoothDevicesDiscovery({
              success: function (res) {
                console.log(res)
              }
            })
            wx.closeBluetoothAdapter({
              success: function (res) {
                console.log(res)
              }
            })
            that.setData({
              header: false,
              controls: that.data.baginMapControls
            })
          }
        })
      }
    });
  },
  //监听寻找到新设备的事件
  onBluetoothDeviceFound: function () {
    var that = this;
    //监听寻找到新设备的事件
    var create = 0;
    that.create = setInterval(function () {
      create++;
      if (create == 4) {
        wx.showModal({
          title: '提示',
          content: '没有搜索到此设备',
          showCancel:false,
          success(){
            that.setData({
              header: false,
              controls: that.data.baginMapControls
            })
            wx.setNavigationBarTitle({
              title: '潮牌共享停车'
            })
            that.getBikeList(that.data.latitude, that.data.longitude)
          }
        })
        clearInterval(that.create)
        wx.stopBluetoothDevicesDiscovery({//停止搜索附近蓝牙的外围设备
          success: function (res) {
            console.log(res, '停止')
          }
        })
        wx.closeBluetoothAdapter({
          success: function (res) {
            console.log(res);
          }
        })
      }
    }, 2000)
    wx.onBluetoothDeviceFound(function (res) {
      console.log(res)
      var deviceId = res.devices[0].deviceId;
      var ua = wx.getSystemInfoSync().platform;//获取设备信息
      if (ua == 'ios') {
        if (res.devices[0].advertisData){
          var buff = res.devices[0].advertisData.slice(2, 8);//当前蓝牙设备的广播内容
          var arrayBuff = Array.prototype.map.call(new Uint8Array(buff), x => ('00' + x.toString(16)).slice(-2)).join(':'); // 将 ArrayBuffer 数据转成 Base64 字符串 或 字符串  
          var arrayMac = arrayBuff.toUpperCase();
          var arr = arrayMac.split(":");//ios取到的mac地址是反的;倒过来
          var app = []
          for (var i = 0; i < arr.length; i++) {
            app.unshift(arr[i])
          }
          arrayMac = app.join(':')
          console.log(arrayMac, that.data.appointment.bluemac)
          if (arrayMac == that.data.appointment.bluemac) {
            clearInterval(that.create)
            that.setData({
              deviceId: deviceId
            })
            wx.stopBluetoothDevicesDiscovery({//停止搜索附近蓝牙的外围设备
              success: function (res) {
                console.log(res, '停止')
                that.createBLEConnection()
              }
            })
            //连接设备      
          }
        }  
      } else {
        if (deviceId == that.data.appointment.bluemac) {
          clearInterval(that.create)
          that.setData({
            deviceId: deviceId
          })
          setTimeout(function () {
            wx.stopBluetoothDevicesDiscovery({//停止搜索附近蓝牙的外围设备
              success: function (res) {
                console.log(res, '停止')         
                  console.log('停止==============')
                  that.createBLEConnection()
              }
            })
          })
        }
      }
    })
  },
  //连接设备      
  createBLEConnection: function () {
    var that = this;
    wx.createBLEConnection({
      deviceId: that.data.deviceId,
      success: function (res) {
        console.log(res, '连接设备成功');
        wx.getBLEDeviceServices({
          deviceId: that.data.deviceId,
          success: function (res) {
            console.log('device services:', res.services)
            that.setData({ services: res.services[0].uuid });
            that.getBLEDeviceCharacteristics()
          },
          fail: function (res) {
            console.log(res, '获取蓝牙设备所有 service（服务）失败');
          }
        })
      },
      fail: function (res) {
        wx.closeBluetoothAdapter({
          success: function (res) {
            console.log(res);
            wx.showToast({
              title: '连接设备失败',
              image: '../../img/err.png',
              success() {
                that.setData({
                  header: false,
                  controls: that.data.baginMapControls
                })
              }
            })
          }
        })
      }
    })
  },
  getBLEDeviceCharacteristics: function () {
    var that = this;
    wx.getBLEDeviceCharacteristics({//获取蓝牙设备所有 characteristic（特征值）
      deviceId: that.data.deviceId,
      serviceId: that.data.services,
      success: function (res) {
        console.log(res)
        that.setData({
          writeDataUUID: res.characteristics[0].uuid,
          readDaraUUID: res.characteristics[1].uuid
        });
        wx.notifyBLECharacteristicValueChange({// 启用 notify 功能
          state: true,
          deviceId: that.data.deviceId,
          serviceId: that.data.services,
          characteristicId: that.data.readDaraUUID,
          success: function (res) {
            console.log('notify', res.errMsg);
            that.writeElectricity()
          },
          fail: function (res) {
            console.log('notify', res.errMsg);
          }
        })
      },
      fail(res) {
        console.log(res)
      }
    })
  },                                                  
  writeElectricity(){
    var that = this;
    wx.onBLECharacteristicValueChange(function (res) {
      var bufferUint = Array.prototype.map.call(new Uint8Array(res.value), x => ('00' + x.toString(16)).slice(-2)).join('');
      console.log(bufferUint, '电量成功', that.data.lock);
      if (bufferUint.slice(6, 8) == '02') {
        that.setData({
          battery_level: parseInt(bufferUint.slice(16, 18), 16)
        })
        if (that.data.lock == '0x03') {
          that.unlocking()
        }else{
          that.writeBLECharacteristicValue()
        }
      }else{
        wx.closeBLEConnection({
          deviceId: that.data.deviceId,
          success: function (res) {
            console.log(res);
            that.setData({
              deviceId: ''
            })
            wx.closeBluetoothAdapter({
              success: function (res) {
                console.log(res);
              }
            })
          }
        })
        wx.showToast({
          title: '开锁超时',
          icon: 'loading',
        })
      }
    })
    //此数据加密后的得来第一次写入
    setTimeout(function () {
      let buffer = new ArrayBuffer(6);
      let dataView = new DataView(buffer);
      var checksum = 0;
      dataView.setUint8(0, '0xA1');
      dataView.setUint8(1, '0x55');
      dataView.setUint8(2, '0x06');
      dataView.setUint8(3, '0x01');
      var check = '0xA1,0x55,0x06,0x01';
      var check = check.split(',')
      for (var i = 0; i < check.length; i++) {
        checksum ^= check[i]
      }
      checksum = ~checksum
      dataView.setUint8(4, checksum);
      dataView.setUint8(5, '0x55');

      //写入低功耗蓝牙设备的特征值的二进制数据值
      wx.writeBLECharacteristicValue({
        deviceId: that.data.deviceId,
        serviceId: that.data.services,
        characteristicId: that.data.writeDataUUID,
        value: buffer,
        success: function (res) {
          console.log(res, '电量写入成功');
        },
        fail: function (res) {
          console.log(res, 'buff fail');
          wx.closeBLEConnection({
            deviceId: that.data.deviceId,
            success: function (res) {
              console.log(res);
              that.setData({
                deviceId: ''
              })
              wx.closeBluetoothAdapter({
                success: function (res) {
                  console.log(res);
                }
              })
            }
          })
        }
      })
    }, 2000);
  },
  writeBLECharacteristicValue(){
    var that=this;
    var bufferUint = ''
    wx.onBLECharacteristicValueChange(function (res) {
      bufferUint = Array.prototype.map.call(new Uint8Array(res.value), x => ('00' + x.toString(16)).slice(-2)).join('');
      console.log(bufferUint,'开锁写入成功');
      if (bufferUint.slice(6, 8) == '04') {
        console.log('开锁写入成功')
        that.writeOrder()
      } else if (bufferUint.slice(6, 8) == '06') {
        wx.showToast({
          title: '关锁成功',
          icon: 'success',
        })
        that.endOrder();
        wx.closeBLEConnection({
          deviceId: that.data.deviceId,
          success: function (res) {
            console.log(res);
            that.setData({
              deviceId: ''
            })
        wx.closeBluetoothAdapter({
              success: function (res) {
                console.log(res);
              }
            })
          }
        })
      } else {
        wx.closeBLEConnection({
          deviceId: that.data.deviceId,
          success: function (res) {
            console.log(res);
            that.setData({
              deviceId: ''
            })
            wx.closeBluetoothAdapter({
              success: function (res) {
                console.log(res);
              }
            })
          }
        })
        wx.showToast({
          title: '开锁超时!',
          icon: 'loading',
        })
      }
    })
    //此数据加密后的得来第一次写入
    setTimeout(function () {
      let buffer = new ArrayBuffer(6);
      let dataView = new DataView(buffer);
      var checksum = 0;
      dataView.setUint8(0, '0xA1');
      dataView.setUint8(1, '0x55');
      dataView.setUint8(2, '0x06');
      dataView.setUint8(3, that.data.lock);
      var check = '0xA1,0x55,0x06,' + that.data.lock;
      var check = check.split(',')
      for (var i = 0; i < check.length; i++) {
        checksum ^= check[i]
      }
      checksum = ~checksum
      dataView.setUint8(4, checksum);
      dataView.setUint8(5, '0x55');

      //写入低功耗蓝牙设备的特征值的二进制数据值
      wx.writeBLECharacteristicValue({
        deviceId: that.data.deviceId,
        serviceId: that.data.services,
        characteristicId: that.data.writeDataUUID,
        value: buffer,
        success: function (res) {
          console.log(res, '开锁写入成功');
        },
        fail: function (res) {
          console.log(res, 'buff fail');
          wx.closeBLEConnection({
            deviceId: that.data.deviceId,
            success: function (res) {
              console.log(res);
              that.setData({
                deviceId: ''
              })
              wx.closeBluetoothAdapter({
                success: function (res) {
                  console.log(res);
                }
              })
            }
          })
        }
      })
    }, 2000);
  },
  writeOrder() {
    var that = this;
    var bufferUint = ''
    wx.onBLECharacteristicValueChange(function (res) {
      bufferUint = Array.prototype.map.call(new Uint8Array(res.value), x => ('00' + x.toString(16)).slice(-2)).join('');
      console.log(bufferUint, '订单号写入');
      if (bufferUint) {
        wx.showToast({
          title: '开锁成功',
          icon: 'success',
        })
        that.order()
      } else{
        wx.closeBLEConnection({
          deviceId: that.data.deviceId,
          success: function (res) {
            console.log(res);
            that.setData({
              deviceId: ''
            })
            wx.closeBluetoothAdapter({
              success: function (res) {
                console.log(res);
              }
            })
          }
        })
        wx.showToast({
          title: '开锁超时',
          icon: 'loading',
        })
      }
    })
    //此数据加密后的得来第一次写入
    setTimeout(function () {
      let buffer = new ArrayBuffer(20);
      let dataView = new DataView(buffer);
      // var checksum = 0;
      dataView.setUint8(0, '0xA1');
      // dataView.setUint8(1, that.data.order_sn);
      // dataView.setUint8(1, '0x55');
      // dataView.setUint8(2, '0x19');
      // dataView.setUint8(3,'0x09');
      // dataView.setUint8(4,that.data.order_sn);
      // console.log(that.data.order_sn)
      var code = '';
      // var array = [];
      var order_sn = that.data.order_sn.split("").join("")
      var s=1
      for (var i = 0; i < order_sn.length; i++) {
        code = order_sn[i].charCodeAt();
        dataView.setUint8(s++, code);
        // array.push(code)
      }  
      // var checksum = 0;
      // var check = '0xA1,0x55,0x19,0x09,' + array;
      // var check = check.split(',')
      // for (var i = 0; i < check.length; i++) {
      //   checksum ^= check[i]
      // }
      // checksum = ~checksum
      // dataView.setUint8(23, checksum);
      // dataView.setUint8(24, '0x55');

      //写入低功耗蓝牙设备的特征值的二进制数据值
      wx.writeBLECharacteristicValue({
        deviceId: that.data.deviceId,
        serviceId: that.data.services,
        characteristicId: that.data.writeDataUUID,
        value: buffer,
        success: function (res) {
          console.log(res, '订单号写入成功');
        },
        fail: function (res) {
          console.log(res, 'buff fail')
        }
      })
    }, 2000);
  },
  //页面加载的函数
  onLoad: function (e) {
    console.log('onLoad');
    wx.setNavigationBarTitle({
      title: '潮牌共享停车'
    })
    var that=this;
    var q = decodeURIComponent(e.q);
    var id = decodeURIComponent(e.q).split('=')[1];
    // var id ='0018171001000027';
    if(!id){//没有登陆的在进入时,id==undefined ,false时 使用之前存储的
      that.setData({
        id: ''
      })
    } else {//直接扫码 存储存储进来
      wx.setStorageSync('id', id)
      that.setData({
        id: id
      })
    }
    if(e.id){
      that.setData({
        id: e.id
      })
    }
  },
  onShow: function () {
    console.log('onshow');
    var that = this;
    var value=wx.getStorageSync('token');
    if(value){
      this.setData({
        lock: ''//开 
      })
      that.userCenter()
      wx.getNetworkType({
        success: function (res) {
          if (res.networkType == 'none') {
            wx.showToast({
              title: '无网络连接',
              icon: 'loading'
            })
          }
        }
      })
      //获取用户的当前位置位置
      wx.getLocation({
        type: 'gcj02',
        success: function (res) {
          that.setData({
            latitude: res.latitude,
            longitude: res.longitude,
          })
          that.paymentMoney()
          that.order();//查看是否有未完成订单
        }
      })
      // 1.创建地图上下文，移动当前位置到地图中心
      this.mapCtx = wx.createMapContext("myMap"); // 地图组件的id
    // this.movetoPosition();
    }else{
      setTimeout(function () {
        wx.navigateTo({
          url: '../index/index'
        })
      }, 1000)
      that.setData({
        controls: that.data.baginMapControls
      })
      wx.getLocation({
        type: 'gcj02',
        success: function (res) {
          that.setData({
            latitude: res.latitude,
            longitude: res.longitude,
          })
        }
      })
      this.mapCtx = wx.createMapContext("myMap"); // 地图组件的id
    }
  },
  onHide:function(){
    var that=this;
     that.setData({
        header:false,
        id: ''
      })
     wx.setNavigationBarTitle({
       title: '潮牌共享停车'
     })
    console.log('onHide')   
  },
  onShareAppMessage: function () {
    return {
      title: '可以让消费者赚钱的智能化城市停车解决方案',
      path: '/pages/map/map' // 分享路径
    }
  }
})