var app = getApp();
Page({
  data: {
    balance:'0.00'
  },
  //去充值
  recharge:function(){
    wx.navigateTo({
      url: 'recharge/recharge'
    })
  },
  menusCode:function(){
    wx.navigateTo({
      url: 'rechargeRecord/rechargeRecord',
    })
  },
  result:function(){
    wx.showModal({
      title: '提示',
      content: '确认退出登录?',
      success: function (res) {
        if (res.confirm) {
          wx.clearStorageSync()
          wx.reLaunch({
            url: '../index/index'
          })
        }
      }
    })
    
  },
  onLoad: function (options) {
    var that=this;
    wx.setNavigationBarTitle({
      title: '我的钱包'
    })
    var userMoney = '/api/v1/userinfo';
    wx.request({
      url: app.globalData.getcode + userMoney,
      data: {
        type: 2,
        userid: wx.getStorageSync('user_id')
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded',
        'token': wx.getStorageSync('token')
      },
      success: function (res) {
        // console.log(res.data)
        if (res.data.code == '0') {
            that.setData({
              balance:res.data.data.money,
            })
        } else if (res.data.code == 304) {
          setTimeout(function () {
            wx.navigateTo({
              url: '../index/index'
            })
          }, 1000)    
        }       
      },
      fail: function (res) {   
        console.log(res)
      }
    })
  }
})