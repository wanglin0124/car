var app = getApp();
Page({
  data: {
    none:false
  },
  onLoad: function (options) {
    //我的行程记录
    var that = this;
    var userTransaction = '/api/v1/userinfo/show';
    wx.request({
      url: app.globalData.getcode + userTransaction,
      data: {
        userid: wx.getStorageSync('user_id'),
        page: 1,
        type:3,
        status:31
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded ' ,// 默认值
        'token': wx.getStorageSync('token'),
      },
      success: function (res) {
        console.log(res);
        if (res.data.data.data==''){
          that.setData({
            none: true
          })
        }
        var array = res.data.data.data;
        var day = '';
        var d = new Date().getDate();
        array.forEach(function (item) {
          var order = item.order_sn.substr(item.order_sn.length - 18)
          day = item.order_sn.slice(6, 8);
          // if (Number(d) - Number(day) == 0) {
          //   item['day'] = '今天'
          // } else if (Number(d) - Number(day) == 1) {
          //   item['day'] = '昨天'
          // } else {
          item['day'] = order.slice(4, 6) + '.' + order.slice(6,8);
          // }
          item['time'] = order.slice(8, 10) + ':' + order.slice(10, 12);
          if (item['way']==3){
            item['way'] ='微信公众号';
          } else if (item['way'] == 1){
            item['way'] = '支付宝';
          } else if (item['way'] == 2) {
            item['way'] = '微信';
          } else if (item['way'] == 4) {
            item['way'] = '微信小程序';
          }
        })
        console.log(new Date().getYear() )
        that.setData({
          array: array,
          newTime: new Date().getFullYear() + '年' + new Date().getMonth()+1 + '月'
        })


      },
      fail: function () {
        console.log(res)
      }
    })
  },
  onShow() {
    wx.getNetworkType({
      success: function (res) {
        console.log(res)
        if (res.networkType == 'none') {
          wx.showToast({
            title: '无网络连接',
            icon: 'loading'
          })
        }
      }
    })
  }
})