var app = getApp();
Page({
  data: {
    money: '50.00',
    clicktag: '0',
    // array: [
    //   {
    //     id: 0, message: '20元', bgd: '../../../img/btn_recharge_coin_nor.png',give:''
    //   }, {
    //     id: 1, message: '50元', bgd: '../../../img/btn_recharge_coin_press.png',
    //     give: ''
    //   },
    //   {
    //     id: 2, message: '100元', bgd: '../../../img/btn_recharge_coin_nor.png',
    //     give: ''
    //   },
    //   {
    //     id: 3, message: '500元', bgd: '../../../img/btn_recharge_coin_nor.png',
    //     give: '赠100'
    //   },
    //   {
    //     id: 4, message: '1000元', bgd: '../../../img/btn_recharge_coin_nor.png',
    //     give: '赠300'
    //   },
    //   {
    //     id: 5, message: '3000元', bgd: '../../../img/btn_recharge_coin_nor.png',
    //     give: '赠100'
    //   }

    // ],
    array: [
      {
        id: 0, message: '20元', bgd: 'white'
      }, {
        id: 1, message: '50元', bgd: 'rgb(250,178,17)'
      },
      {
        id: 2, message: '100元', bgd: 'white'
      },
      {
        id: 3, message: '200元', bgd: 'white'
      }
    ],
    id: ''
  },
  onLoad: function (options) {
    if (options.id){
      this.setData({
        id: options.id
      })   }

  },
  changeColor: function (event) {
    var that = this;
    var id = event.currentTarget.dataset.id;
    var arr = new Array();
    for (var i = 0; i < that.data.array.length; ++i) {
      if (id == that.data.array[i].id) {
        that.data.array[i].bgd = 'rgb(250,178,17)';
      } else {
        that.data.array[i].bgd = 'white'
      }
      arr.push(that.data.array[i])
    }
    that.setData({
      array: arr,
      money: event.currentTarget.dataset.message
    });
  },
  affirm: function () {
    var that = this;
    var money = parseInt(that.data.money);
    if (money == 0) {
      wx.showModal({
        title: '提示',
        content: '请选择充值金额!'
      })
    } else {
      if (that.data.clicktag == 0) {
        that.setData({
          clicktag: 1
        })
        setTimeout(function () {
          that.setData({
            clicktag: 0
          })
        }, 1000);
        var wechatApi = '/api/v1/wechat/create';
        wx.request({
          url: app.globalData.getcode + wechatApi,
          data: {
            userid: wx.getStorageSync('user_id'),
            openid: wx.getStorageSync('openid'),
            prices: money,
            type: 1
          },
          header: {
            'content-type': 'application/x-www-form-urlencoded ',
            'token': wx.getStorageSync('token'),
          },
          success: function (res) {
            console.log(res.data);
            if (res.data.code == 0) {
              console.log(res.data.data);
              var obj = JSON.parse(res.data.data)
              console.log(obj.appId)
              wx.requestPayment({
                'timeStamp': obj.timeStamp,
                'nonceStr': obj.nonceStr,
                'package': obj.package,
                'signType': 'MD5',
                'paySign': obj.paySign,
                success: function (res) {
                  console.log(res);
                  wx.reLaunch({
                    url: '../../map/map?id=' + that.data.id,
                  })
                },
                fail: function (res) {

                }
              })
            } else {
              wx.showToast({
                title: res.data.info,
                icon: 'loading'
              })
            }
          },
          fail: function (res) {
            console.log(res)
            wx.showToast({
              title: '无网络连接',
              icon: 'loading'
            })
          }
        })
      }
    }
  }
})