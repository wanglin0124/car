const app = getApp()
Page({
  data: {
   getCodeBtnProperty: {  //获取验证码的颜色
      Background: 'rgb(224, 224, 224)',
      disabled: false,
      title: '获取验证码',
      border: '2rpx solid rgb(224, 224, 224)'
    },
    disabled:false,
    showModal:false
  },
  //输入手机号
  phoneTfInput: function (e) {
    var that = this;
    var inputValue = e.detail.value
    var length = e.detail.value.length;
    that.setData({
      inputValue: inputValue,
    })
    if (length == 11) {
      that.setData({
        focus_pwd: 'true',
        focus_user: false,
      })
    }
  },
  //获取验证码
  getCodeAct: function () {
    var that = this;
    var inputValue = that.data.inputValue;
    if ((/^1[34578]\d{9}$/.test(inputValue))) {
      var code = '/api/v1/login/create';
      wx.request({
        url: app.globalData.getcode + code,
        data: { 
          mobile: inputValue ,
          status:1
        },
        header: {
          'content-type': 'application/x-www-form-urlencoded ' 
        },
        success: function (res) {
          console.log(res)
          var statu = res.data.code
          if (statu == '0') {
            wx.showToast({
              title: res.data.info,
              icon: 'success',
              duration: 2000,
            })
            //启动定时器
            var number = 60;
            var time = setInterval(function () {
              number--;
              that.setData({
                'getCodeBtnProperty.title': number + 's',
                'getCodeBtnProperty.disabled': true,
                'getCodeBtnProperty.Background': '#f2f2f2',
                'getCodeBtnProperty.border': '2rpx solid rgb(246, 156, 40)',
              })
              if (number == 0) {
                that.setData({
                  'getCodeBtnProperty.title': '重新获取',
                  'getCodeBtnProperty.disabled': false,
                  'getCodeBtnProperty.border': '2rpx solid rgb(224, 224, 224)',
                  'getCodeBtnProperty.Background': 'rgb(224, 224, 224)',
                })
                clearInterval(time);
              }
            }, 1000);
          }else{
           wx.showModal({
             title: '警告!',
             content: res.data.info,
           })
          }
        },
        fail: function (res) {
          console.log(res)
        }
      })
    } else {
      wx.showModal({
        title: '提示',
        content: '手机号不正确',
        showCancel: false,
      })
    }
  },
  //输入验证码
  codeTfInput: function (e) {
    var inputCode = e.detail.value;
    this.setData({
      inputCode:inputCode
    })
  },
  //注册登录
  login: function () {
    //光标取消
    var that = this;
    that.setData({
      disabled: true
    })
    if (!(/^1[34578]\d{9}$/.test(that.data.inputValue))){
      wx.showModal({
        title: '提示',
        content:'请输入正确的手机号',
        icon:'loading',
        showCancel:false,
      })
      that.setData({
        disabled: false
      })
    } else if (that.data.inputCode==undefined){
      wx.showModal({
        title: '提示',
        content: '请输入正确验证码',
        icon: 'loading',
        showCancel: false,
      })
      that.setData({
        disabled: false
      })
    } else{
      //请求接
      var login = '/api/v1/login/show';
      //发起网络请求
        wx.request({
          url: app.globalData.getcode + login,
          data: {
            mobile: that.data.inputValue,
            code: that.data.inputCode
          },
          header: {
            'content-type': 'application/x-www-form-urlencoded'
          },
          success: function (res) {
            console.log(res)
            var statu = res.data.code
            if (statu == 0) {
              wx.setStorageSync('mobile', that.data.inputValue);
              var token = res.data.data.token;
              wx.setStorageSync('token', token);//将token保存到程序内
              var user_id = res.data.data.user_id;
              wx.setStorageSync('user_id', user_id); //将user_id保存到程序内
              wx.showToast({
                title: '登录中',
                icon: 'loading',
                mask: true,
                duration: 2000,
              })
              var getOpenId = '/api/v1/wechat';
              wx.request({
                url: app.globalData.getcode + getOpenId,
                data: {
                  userid: user_id,
                  code: that.data.misi,
                },
                header: {
                  'content-type': 'application/x-www-form-urlencoded',
                  'token': token,
                },
                success: function (res) {
                  console.log(res)
                  that.setData({
                    disabled: false
                  })
                  wx.setStorageSync('openid', res.data.data);
                  //转回主界面
                  setTimeout(function () {
                    wx.reLaunch({
                      url: '../map/map?id=' + wx.getStorageSync('id'),
                    })
                  }, 1500)
                },fail(){
                  that.setData({
                    disabled: false
                  })
                }
              })
            } else {
              that.setData({
                disabled: false
              })
              wx.showModal({
                title: '提示',
                content: res.data.info,
                showCancel: false
              })
            }

          },
          fail: function (res) {
            that.setData({
              disabled: false
            })
            wx.showToast({
              title: '无网络连接',
              icon: 'loading'
            })
          }
        }) 
    
    }
  },
  //收不到验证客服
  phone:function(){
    var that = this;
    var userMoney = '/api/v1/show';
    wx.request({
      url: app.globalData.getcode + userMoney,
      data: {
        type: 1,
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        wx.makePhoneCall({
          phoneNumber: res.data.data[0].mobile
        })
      }
    })
  },
  again(){
    var that=this
    wx.login({
      success: function (res) {
        wx.setStorageSync('misi', res.code)

        if (res.code) {
          //发起网络请求  
          that.setData({
            misi: res.code
          })
        } else {
          console.log('获取用户登录态失败！' + res.errMsg)
        }
      }
    }); 
  },
  onLoad:function(){
    var that=this;
    if (wx.getStorageSync('mobile')){
      this.setData({
        showModal: false,
        value: wx.getStorageSync('mobile'),//界面手机号
        inputValue: wx.getStorageSync('mobile'),
        focus_pwd: 'true',
        focus_user: false,
      })
    }else{
      this.setData({
        showModal: true
      });
    };
    wx.login({
      success: function (res) {
        console.log(res)
        wx.setStorageSync('misi', res.code)
        
        if (res.code) {
          //发起网络请求  
          that.setData({
            misi: res.code
          })    
        } else {
          console.log('获取用户登录态失败！' + res.errMsg)
        }
      }
    }); 
  }, 
  onShow() {
    wx.setNavigationBarTitle({
      title: '潮牌共享停车'
    })
    wx.getNetworkType({
      success: function (res) {
        if (res.networkType == 'none') {
          wx.showToast({
            title: '无网络连接',
            icon: 'loading'
          })
        }
      }
    })
  },
  confirm(){
    this.setData({
      showModal: false
    });
  },
  /* 获取手机号 */
  getPhoneNumber: function (e) {
    var that=this;
    var authorize = '/api/v1/authorize';
    if (e.detail.errMsg == 'getPhoneNumber:fail user deny') {
     console.log('授权失败')
    } else {
      wx.request({
        url: app.globalData.getcode + authorize,
        data: {
          code: that.data.misi,
          encryptedData: e.detail.encryptedData,
          iv: e.detail.iv,
          way:1
        },
        method: 'POST',
        header: {
          'content-type': 'application/x-www-form-urlencoded'
        },
        success: function (res) {
          console.log(res)
          if(res.data.code==0){
            that.setData({
              inputValue: res.data.data.mobile,
              value: res.data.data.mobile,//界面手机号
              focus_pwd: 'true',
              focus_user: false,
            })
            that.getCodeAct()
          }else{
            that.setData({
              focus_pwd: false,
              focus_user: 'true',
            })
          }
        }
      })
      that.again()
    }
  }
})
