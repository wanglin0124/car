//app.js
App({
  onLaunch: function () {
    var that=this
    wx.getSystemInfo({
      success: function (res) {
        var kScreenW = res.windowWidth / 375;
        var kScreenH = res.windowHeight / 603;
        that.globalData.kScreenW=kScreenW
        that.globalData.kScreenH =kScreenH
        that.globalData.Height = res.windowHeight
      }
    })
  },
  globalData: {
    getcode: "https://www.ipower001.com",
  }
})
