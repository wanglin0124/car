// pages/center/center.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    mobile: '请点击头像登录'
  },
  onLoad: function (options) {
  },
  onShow(){
    if (wx.getStorageSync('mobile')) {
      this.setData({
        mobile: wx.getStorageSync('mobile')
      })
    }
  },
  header(){
    if (!wx.getStorageSync('mobile')) {
     wx.navigateTo({
       url: '../index/index',
     })
    }
  },
  wallet(){
    wx.navigateTo({
      url: 'wallet/wallet',
    })
  },
  //客服电话
  customer: function () {
    wx.makePhoneCall({
      phoneNumber: '010-57726047'
    })
  },
  loginOut: function () {
    var that=this;
    wx.showModal({
      title: '提示',
      content: '确认退出登录?',
      success: function (res) {
        if (res.confirm) {
          wx.removeStorageSync('openid');
          wx.removeStorageSync('mobile');
          wx.removeStorageSync('token');
            //  wx.clearStorageSync()
          that.setData({
            mobile:'请点击头像登录'
          })
        }
      }
    })

  },
})