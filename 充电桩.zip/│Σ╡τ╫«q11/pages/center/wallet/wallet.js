var app = getApp();
Page({
  data: {
    balance:'0.00'
  },
  //去充值
  recharge:function(){
    wx.navigateTo({
      url: 'recharge/recharge'
    })
  },
  menusCode:function(){
    wx.navigateTo({
      url: 'rechargeRecord/rechargeRecord',
    })
  },
  onLoad: function (options) {
    var that=this;
    wx.setNavigationBarTitle({
      title: '我的钱包'
    })
    var userMoney = '/App/V1/User/Amount';
    wx.request({
      url: app.globalData.getcode + userMoney,
      data: {
        token: wx.getStorageSync('token')
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        console.log(res);
        if (res.data.status==200){
          that.setData({
            balance: res.data.data.amount
          })
        }
      },
      fail: function (res) {   
        console.log(res)
      }
    })
  }
})