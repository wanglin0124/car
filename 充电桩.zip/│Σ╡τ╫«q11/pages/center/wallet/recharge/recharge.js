var app = getApp();
Page({
  data: {
    approveImg: '../../../../img/ico_chargeset_way_press@2x.png',
    money:'0.00',  
    clicktag: '0',  
    array: [
      {
        id: 0, message: '10元', image: '../../../../img/btn_recharge_coin_nor@2x.png',
      }, {
        id: 1, message: '20元', image: '../../../../img/btn_recharge_coin_nor@2x.png',
      },
      {
        id: 2, message: '50元', image: '../../../../img/btn_recharge_coin_nor@2x.png'
      },
      {
        id: 3, message: '100元', image: '../../../../img/btn_recharge_coin_nor@2x.png',
      }, {
        id: 4, message: '200元', image: '../../../../img/btn_recharge_coin_nor@2x.png',
      },
      {
        id: 5, message: '300元', image: '../../../../img/btn_recharge_coin_nor@2x.png'
      }
    ] 
  },
  onLoad: function () {
   
  },
  changeColor: function (event) {
    var that = this;
    var id = event.currentTarget.dataset.id;
    var arr=new Array();
    for(var i=0;i<that.data.array.length;++i){
      if(id==that.data.array[i].id){
        that.data.array[i].image = '../../../../img/btn_recharge_coin_press@2x.png'
      }else{
        that.data.array[i].image = '../../../../img/btn_recharge_coin_nor@2x.png'
      }
      arr.push(that.data.array[i])
    }
    that.setData({
     array:arr,
     money: event.currentTarget.dataset.message
    })
  },
  affirm:function(){
    var that = this;
    var money = parseInt(that.data.money);
    if (money==0){
      wx.showModal({
        title: '提示',
        content: '请选择充值金额!',
        showCancel: false
      })
    }else{
      console.log(that.data.clicktag)
      if (that.data.clicktag == 0) {
        that.setData({
          clicktag: 1
        })
        setTimeout(function () {
          that.setData({
            clicktag: 0
          })
        }, 2000);
        var wechatApi = '/app/V1/Wechat/smallpay';
        wx.request({
          url: app.globalData.getcode + wechatApi,
          data: {
            token: wx.getStorageSync('token'),
            openid: wx.getStorageSync('openid'),
            total_fee: parseFloat(that.data.money),
          },
          method: 'POST',
          header: {
            'content-type': 'application/x-www-form-urlencoded '
          },
          success: function (res) {
            console.log(res);
            if (res.data.status == 200) {
              console.log(res.data);
              var obj = JSON.parse(res.data.data)
              console.log(obj.timeStamp)
              wx.requestPayment({
                'timeStamp': obj.timeStamp,
                'nonceStr': obj.nonceStr,
                'package': obj.package,
                'signType': 'MD5',
                'paySign': obj.paySign,
                success: function (res) {
                  console.log(res);
                  wx.reLaunch({
                    url: '../../map/map',
                  })
                },
                fail(res){
                  console.log(res);
                }
              })
            }
          },
          fail: function (res) {
            console.log(res)
          }
        })
      }
    }

  }  
})