var app = getApp();
Page({
  data: {
    none:false
  },
  onLoad: function (options) {
    //我的行程记录
    var that = this;
    var userTransaction = '/App/V1/Recharge/record';
    wx.request({
      url: app.globalData.getcode + userTransaction,
      data: {
        token: wx.getStorageSync('token'),
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded ' ,// 默认值
      },
      success: function (res) {
        console.log(res);
        if (res.data.status==200){
          if(!res.data.data){
            that.setData({
              none: true
            })
          }else{
            var array = res.data.data;
            var day = '';
            var d = new Date().getDate();
            var a=[]
            array.forEach(function (item) {
              if(item.status=='已支付'){
                var date = new Date();
                date.setTime(item.create_time * 1000);
                var m = date.getMonth() + 1;
                m = m < 10 ? ('0' + m) : m;
                var d = date.getDate();
                d = d < 10 ? ('0' + d) : d;
                var h = date.getHours();
                h = h < 10 ? ('0' + h) : h;
                var minute = date.getMinutes();
                minute = minute < 10 ? ('0' + minute) : minute;
                item['day'] = m + '.' + d;
                item['time'] = h + ':' + minute
                a.push(item)
              }
            })
            that.setData({
              array: a,
              newTime: new Date().getFullYear() + '年' + (parseInt(new Date().getMonth()) + 1) + '月'
            })
          }
        }
      },
      fail: function () {
        console.log(res)
      }
    })
  },
  onShow() {
    wx.getNetworkType({
      success: function (res) {
        console.log(res)
        if (res.networkType == 'none') {
          wx.showToast({
            title: '无网络连接',
            icon: 'loading'
          })
        }
      }
    })
  }
})