const app = getApp()
Page({
  data: {
   getCodeBtnProperty: {  //获取验证码的颜色
      Background: 'rgb(78, 228, 193)',
      disabled: false,
      title: '获取验证码',
    },
    disabled:false,
    showModal:false
  },
  //输入手机号
  phoneTfInput: function (e) {
    var that = this;
    var inputValue = e.detail.value
    var length = e.detail.value.length;
    that.setData({
      inputValue: inputValue,
    })
    if (length == 11) {
      that.setData({
        // focus_pwd: 'true',
        focus_user: false,
      })
    }
  },
  //获取验证码
  getCodeAct: function () {
    var that = this;
    var inputValue = that.data.inputValue;
    if ((/^1[34578]\d{9}$/.test(inputValue))) {
      var code = '/App/V1/User/sendCode';
      wx.request({
        url: app.globalData.getcode + code,
        data: { 
          mobile: inputValue
        },
        header: {
          'content-type': 'application/x-www-form-urlencoded ' 
        },
        success: function (res) {
          console.log(res)
          var statu = res.data.status
          if (statu == '200') {
            wx.showToast({
              title: res.data.message,
              icon: 'success',
              duration: 2000,
            })
            //启动定时器
            var number = 60;
            var time = setInterval(function () {
              number--;
              that.setData({
                'getCodeBtnProperty.title': number + 's',
                'getCodeBtnProperty.disabled': true,
                'getCodeBtnProperty.Background': 'rgb(201,201,201)',
              })
              if (number == 0) {
                that.setData({
                  'getCodeBtnProperty.title': '重新获取',
                  'getCodeBtnProperty.disabled': false,
                  'getCodeBtnProperty.Background': 'rgb(78, 228, 193)',
                })
                clearInterval(time);
              }
            }, 1000);
          }else{
           wx.showModal({
             title: '警告!',
             content: res.data.message,
           })
          }
        },
        fail: function (res) {
          console.log(res)
        }
      })
    } else {
      wx.showModal({
        title: '提示',
        content: '手机号不正确',
        showCancel: false,
      })
    }
  },
  //输入验证码
  codeTfInput: function (e) {
    var inputCode = e.detail.value;
    this.setData({
      inputCode:inputCode
    })
  },
  //注册登录
  login: function () {
    //光标取消
    var that = this;
    that.setData({
      disabled: true
    })
    if (!(/^1[34578]\d{9}$/.test(that.data.inputValue))){
      wx.showModal({
        title: '提示',
        content:'请输入正确的手机号',
        icon:'loading',
        showCancel:false,
      })
      that.setData({
        disabled: false
      })
    } else if (that.data.inputCode==undefined){
      wx.showModal({
        title: '提示',
        content: '请输入正确验证码',
        icon: 'loading',
        showCancel: false,
      })
      that.setData({
        disabled: false
      })
    } else{
      //请求接
      var login = '/App/V1/User/Sign';
      //发起网络请求
        wx.request({
          url: app.globalData.getcode + login,
          data: {
            mobile: that.data.inputValue,
            code: that.data.inputCode
          },
          header: {
            'content-type': 'application/x-www-form-urlencoded'
          },
          success: function (res) {
            // console.log(res)
            var statu = res.data.status
            if (statu == 200) {
              wx.setStorageSync('tel', that.data.inputValue);
              wx.setStorageSync('mobile', that.data.inputValue);
              var token = res.data.data.token;
              wx.setStorageSync('token', token);//将token保存到程序内
              wx.showToast({
                title: '登录中',
                icon: 'loading',
                mask: true,
                duration: 2000,
              })
              // setTimeout(function () {
              //   wx.switchTab({
              //     url: '../map/map',
              //   })
              // }, 1500)
              var getOpenId = '/app/V1/Wechat/getsmallOpenId';
              wx.request({
                url: app.globalData.getcode + getOpenId,
                data: {
                  token: token,
                  code: that.data.misi,
                },
                header: {
                  'content-type': 'application/x-www-form-urlencoded',
                  'token': token,
                },
                success: function (res) {
                  // console.log(res)
                  if (res.data.status==200){
                    that.setData({
                      disabled: false
                    })
                    wx.setStorageSync('openid', res.data.data);
                    //转回主界面
                    setTimeout(function () {
                      // if (that.data.sn){
                      //   wx.switchTab({
                      //     url: '../scancode/scancode',
                      //   })
                      // }else{
                      //   wx.switchTab({
                      //     url: '../map/map',
                      //   })
                      // }
                      wx.switchTab({
                        url: '../scancode/scancode',
                      })
                    }, 1500)
                  }else{
                    wx.showToast({
                      title: 'openid NO!',
                    })
                    that.setData({
                      disabled: false
                    })
                  }
                },fail(){
                  that.setData({
                    disabled: false
                  })
                }
              })
            } else {
              that.setData({
                disabled: false
              })
              wx.showModal({
                title: '提示',
                content: res.data.message,
                showCancel: false
              })
            }

          },
          fail: function (res) {
            that.setData({
              disabled: false
            })
            wx.showToast({
              title: '无网络连接',
              icon: 'loading'
            })
          }
        }) 
    
    }
  },
  //收不到验证客服
  phone:function(){
    var that = this;
    var userMoney = '/api/v1/show';
    wx.request({
      url: app.globalData.getcode + userMoney,
      data: {
        type: 1,
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        wx.makePhoneCall({
          phoneNumber: res.data.data[0].mobile
        })
      }
    })
  },
  again(){
    var that=this
    wx.login({
      success: function (res) {
        if (res.code) {
          //发起网络请求  
          that.setData({
            misi: res.code
          })
        } else {
          console.log('获取用户登录态失败！' + res.errMsg)
        }
      }
    }); 
  },
  onLoad:function(options){
    var that=this;
    if (wx.getStorageSync('tel')){
      this.setData({
        showModal: false,
        value: wx.getStorageSync('tel'),//界面手机号
        inputValue: wx.getStorageSync('tel'),
        // focus_pwd: 'true',
        focus_user: false,
      })
    }else{
      this.setData({
        showModal: true
      });
    };
    wx.login({
      success: function (res) {
        if (res.code) {
          //发起网络请求  
          that.setData({
            misi: res.code,
          })
          if (options.sn) {
            that.setData({
              sn: options.sn,
            })
          }
        } else {
          console.log('获取用户登录态失败！' + res.errMsg)
        }
      }
    }); 
  }, 
  onShow() {
    wx.setNavigationBarTitle({
      title: '共电科技'
    })
    wx.getNetworkType({
      success: function (res) {
        if (res.networkType == 'none') {
          wx.showToast({
            title: '无网络连接',
            icon: 'loading'
          })
        }
      }
    })
  },
  confirm(){
    this.setData({
      showModal: false
    });
  },
  /* 获取手机号 */
  getPhoneNumber: function (e) {
    var that=this;
    var authorize = '/App/V1/Authorize/smallMobile';
    if (e.detail.errMsg == 'getPhoneNumber:fail user deny') {
     console.log('授权失败')
    } else {
      wx.request({
        url: app.globalData.getcode + authorize,
        data: {
          code: that.data.misi,
          encryptedData: e.detail.encryptedData,
          iv: e.detail.iv
        },
        header: {
          'content-type': 'application/x-www-form-urlencoded'
        },
        success: function (res) {
          console.log(res)
          if (res.data.status==200){
            that.setData({
              inputValue: res.data.data.mobile,
              value: res.data.data.mobile,//界面手机号
              focus_pwd: 'true',
              focus_user: false,
            })
            that.getCodeAct()
          }else{
            that.setData({
              focus_pwd: false,
              focus_user: 'true',
            })
          }
        }
      })
      that.again()
    }
  }
})
