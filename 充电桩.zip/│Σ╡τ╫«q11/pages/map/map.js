const app = getApp();
var QQMapWX = require('../../utils/qqmap-wx-jssdk.min.js');
//获取应用实例
Page({
  data: {
    order: false,
    latitude: 0,  //用户当前位置
    longitude: 0,
    Height: app.globalData.Height, //地图的高
    mapScale:13,
    controls: [   
      {
        id: 1,
        iconPath: '../../img/ico_orientation@2x.png',
        position: {
          left: app.globalData.kScreenW * 177,
          top: app.globalData.kScreenH * 264,
          width: app.globalData.kScreenW* 20,
          height: app.globalData.kScreenH * 75,
        },
        clickable: false,
      },
      //显示位置按钮
      {
        id: 2,
        iconPath: '../../img/imgs_main_location@2x.png',
        position: {
          left: app.globalData.kScreenW * 30,
          top: app.globalData.kScreenH * 40,
          width: app.globalData.kScreenW * 50,
          height: app.globalData.kScreenH * 55,
        },
        clickable: true,
      }
    ]
  },
  //控件的点击事件
  controltap: function (e) {
    var that = this;
    var id = e.controlId
    if (id == 2) {
      //定位当前位置
      that.movetoPosition();
    }
  },
  //请求附近单车列表
  getBikeList: function (latitude, longitude) {
    var that = this;
    var equipmentIndex = '/App/V1/Equipment/map'
    wx.request({
      url: app.globalData.getcode + equipmentIndex,
      data: {
        token:wx.getStorageSync('token'),
        lat:latitude,
        lng: longitude
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded',
      },
      success: function (res) {
        console.log('附近充电桩列表')
        console.log(res)
        if (res.data.status == 200) {
          var iconPath = '../../img/ico_charger_load_landmark@2x.png';
          var bikeArr = res.data.data;
          //附近地锁
          var markers = [];
          var markers1 = [];
          if (bikeArr.length > 40) {//最多只返回40辆
            for (var i = 0; i <= 40; ++i) {
              var marker = {
                latitude: Number(bikeArr[i].lat),
                longitude: Number(bikeArr[i].lng),
                iconPath: iconPath,
                id: i,
                width: 36,
                height: 40
              }
              var dataOpen = {//得到车位信息
                sn: bikeArr[i].sn,
                location: bikeArr[i].location,
                nickname: bikeArr[i].nickname,
                latitude: Number(bikeArr[i].lat),
                longitude: Number(bikeArr[i].lng),
                passageway: bikeArr[i].passageway
              }
              markers1.push(dataOpen)//车位信息压入数组
              markers.push(marker)
            }
          } else {//小于40辆的显示
              bikeArr.forEach(function (item, index) {
                var marker = {
                  latitude: Number(item.lat),
                  longitude: Number(item.lng),
                  iconPath: iconPath,
                  id: index,
                  width: 40,
                  height: 40
                }
                var dataOpen = {//得到车位信息
                  sn: item.sn,
                  location: item.location,
                  nickname: item.nickname,
                  latitude: Number(item.lat),
                  longitude: Number(item.lng),
                  passageway: item.passageway
                }
                markers1.push(dataOpen)//车位信息压入数组
                markers.push(marker)
              })    
          }   
          that.setData({
            markers: markers,
            dataOpen: markers1,
          })    
        }
      },
      fail: function (res) {
        console.log(res)
      }
    })
  },
  map(){
    this.setData({
      appointment:false
    })
  },
  //点击markers触发
  markertap(e){
    var that=this;                  
    var open = e.target.dataset.open;
    console.log(open)
    for (var i = 0; i < open.length; i++) {
      if (e.markerId == i) {
        that.setData({
          open:
          {
            location: open[i].location,
            nickname: open[i].nickname,
            latitude: open[i].latitude,
            longitude: open[i].longitude,
          },
          appointment:true
        })
        var arr = Object.keys(open[i].passageway);
        var len = arr.length;
        if (open[i].passageway==''){
          that.setData({
            td:'无可用通道'
          })
        }else{
          that.setData({
            td: '有'+len+'个可用通道'
          })
        }
      }
    }
    // 实例化API核心类
    var demo = new QQMapWX({
      key: 'DJPBZ-VMVWO-P3SWK-ST2YU-WGHBQ-27BXS' // 必填
    });
    // 调用接口计算距离
    demo.calculateDistance({
      mode: 'driving',
      to: [{
        latitude: that.data.open.latitude,
        longitude: that.data.open.longitude
      }],
      success: function (res) {
        console.log(res)
        var distance = res.result.elements[0].distance
        if (parseInt(distance) >= 1000) {
          distance = Math.round(distance / 1000 * Math.pow(10, 1)) / Math.pow(10, 1) + '千米'
        } else {
          distance = distance + "米"
        }
        that.setData({
          'open.distance': distance
        })
        console.log(that.data.open.distance)
      },
      fail: function (res) {
        console.log(res);
      }
    });
  },
  //导航
  navigation(){
    var that=this; 
    wx.openLocation({
      latitude: Number(that.data.open.latitude),
      longitude: Number(that.data.open.longitude),
      address:that.data.open.address,
      scale: 28
    })
  },
  // 地图视野改变事件
  bindregionchange: function (e) {
    var that = this; 
    that.mapCtx.getCenterLocation({
      success: function (res) {
        if(e.type == "end") {// 停止拖动，显示单车位置       
          that.getBikeList(res.latitude, res.longitude);//查询附近车辆,与正在进行中的订单
        }
      }
    })  
  },
  Tdao(){
    if (this.data.td=='有可用通道'){
      wx.navigateTo({
        url: 'doubt/doubt?passageway=' + this.data.passageway,
      })
    }
  },
  // 定位函数，移动位置到地图中心
  movetoPosition: function () {
    var that = this
    that.mapCtx.moveToLocation();
    that.setData({
      mapScale: 16,
    })  
  },
  //待处理订单查询
  order: function () {
    var that = this;
    var getUnpaid = '/App/V1/Order/getUnpaid';
    wx.request({
      url: app.globalData.getcode + getUnpaid,
      data: {
        token: wx.getStorageSync('token'),
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
       console.log(res);
       if(res.data.status==802){
         that.setData({
           order:true,
           pay_amount: res.data.data.pay_amount,
           order_number: res.data.data.number
         })
       } else if (res.data.status == 801){
         that.setData({
           order_number: res.data.data.number
         })
          wx.redirectTo({
            url: '../scancode/ddSetting/start/start?order_number='+res.data.data.number,
          })
       } else if (res.data.status == 999){
         wx.removeStorageSync('openid');
         wx.removeStorageSync('token');
         wx.removeStorageSync('mobile');
         wx.showModal({
           title: '共电科技',
           content: '您还没有登录哦!',
           confirmText: '登录',
           success(res) {
             if (res.confirm) {
               wx.navigateTo({
                 url: '../index/index',
               })
             }
           }
         })
       } else if (res.data.status==200){
         that.setData({
           order: false
         })
       }
      }
    })
  },
  //有未完成订单去支付
  orderTap: function () {
    wx.navigateTo({
      url: '../payment/payment?pay_amount=' + this.data.pay_amount + '&&order_number=' + this.data.order_number,
    })
  },
  //页面加载的函数
  onLoad: function (e) {
    console.log('onLoad');
    var that=this;
    var q = decodeURIComponent(e.q);
    var id = decodeURIComponent(e.q).split('=')[1];
  },
  onShow: function () {
    console.log('onshow');
    var that = this;
    var value=wx.getStorageSync('tel');
    if(value){
      that.order()
      wx.getNetworkType({
        success: function (res) {
          if (res.networkType == 'none') {
            wx.showToast({
              title: '无网络连接',
              icon: 'loading'
            })
          }
        }
      })
      //获取用户的当前位置位置
      wx.getLocation({
        type: 'gcj02',
        success: function (res) {
          that.setData({
            latitude: res.latitude,
            longitude: res.longitude,
          })
          that.getBikeList(res.latitude, res.longitude)
        }
      })
      // 1.创建地图上下文，移动当前位置到地图中心
      this.mapCtx = wx.createMapContext("myMap"); // 地图组件的id
    }else{
      setTimeout(function () {
        wx.navigateTo({
          url: '../index/index'
        })
      }, 2000)
      wx.getLocation({
        type: 'gcj02',
        success: function (res) {
          that.setData({
            latitude: res.latitude,
            longitude: res.longitude,
          })
          that.getBikeList(res.latitude, res.longitude)
        }
      })
      this.mapCtx = wx.createMapContext("myMap"); // 地图组件的id
    }
  },
  onHide:function(){
    var that=this;
     that.setData({
        header:false,
        id: ''
      })
    console.log('onHide')   
  },
  onShareAppMessage: function () {
    return {
      title: '共电充电桩',
      path: '/pages/map/map' // 分享路径
    }
  }
})