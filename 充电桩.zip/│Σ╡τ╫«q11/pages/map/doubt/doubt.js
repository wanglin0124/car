const app = getApp();
Page({
  data: {
  
  },
  onLoad: function (options) {
    var that=this;   
    var passagement = JSON.parse(options.passageway)
    var arr = Object.keys(passagement);
    var len = arr.length;
    for (var i in passagement)  {
      if (passagement[i] == 1) {
        passagement[i]='可用';
      }
    }
    that.setData({
      passagement: passagement,
      len :len
    })
  },
  sel(){
    wx.switchTab({
      url: '../map',
    })
  }
})