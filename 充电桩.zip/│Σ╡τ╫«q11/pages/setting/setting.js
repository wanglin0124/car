var app = getApp();
Page({
  data: {
    index:0,
    style: 'rgb(78,228,193)',
    style1: ''
  },
  onLoad: function () {
    var that=this;
    var index = '/app/v1/bike/index'
    wx.request({
      url: app.globalData.getcode + index,
      data: {
        token: wx.getStorageSync('token'),
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded',
      },
      success(res) {
        console.log(res)
        var arr=[];
        var obj = res.data.data.brand
        for (var i in obj) {
          arr.push(obj[i]); //属性
        }
        arr.push('自定义'); //属性
        that.setData({
          array:arr
        })
        console.log(that.data.array)
      }
    })
  },
  login(){
    wx.switchTab({
      url: '../map/map'
    })
  },
  style(){
    this.setData({
      style:'rgb(78,228,193)',
      style1: ''
    })
  },
  style1() {
    this.setData({
      style1: 'rgb(78,228,193)',
      style: ''
    })
  },
  bindPickerChange: function (e) {
    var that = this;
    console.log('picker发送选择改变，携带值为', e.detail.value);
    this.setData({
      index: e.detail.value,
      school_id: that.data.array[e.detail.value].id
    })
    console.log(that.data.school_id)
  },
  idName(e) {
    var that = this;
    that.setData({
      username: e.detail.value
    })
  },
  idNumber: function (e) {
    var that = this;
    that.setData({
      card: e.detail.value
    })
  }
})
