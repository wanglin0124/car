var app = getApp();
Page({
  data: {
  
  },
  onLoad: function (options) {
    this.setData({
      money:options.money
    })
    this.userPays()
  },
  userPays: function () {
    var that = this;
    var Amount = '/App/V1/User/Amount'
    wx.request({
      url: app.globalData.getcode + Amount,
      data: {
        token: wx.getStorageSync('token'),
      },
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded '
      },
      success: function (res) {
        console.log(res);
        that.setData({
          amount: '余额'+res.data.data.amount+'元'
        })
      }
    })
  },
  btn(){
    wx.switchTab({
      url: '../map/map',
    })
  }
})