var app = getApp();
Page({
  data: {
  }, 
  onLoad: function (options) {
    console.log(options)
    this.setData({
      order_number: options.order_number
    })
    if (options.pay_amount){
      this.setData({
        pay_amount: options.pay_amount
      });
    }else{
      this.order();
    }
    this.userPays()
  },
  //待处理订单查询
  order: function () {
    var that = this;
    var getUnpaid = '/App/V1/Order/getUnpaid';
    wx.request({
      url: app.globalData.getcode + getUnpaid,
      data: {
        token: wx.getStorageSync('token'),
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        console.log(res);
        that.setData({
          pay_amount:res.data.data.pay_amount
        })
      }
    })
  },
  affirm:function(){
    var that = this;
    var userPays = '/App/V1/Order/pay'
    if (parseInt(that.data.pay_amount) > parseInt(that.data.amount)){
      that.setData({
        show:true
      })
    }else{
      wx.request({
        url: app.globalData.getcode + userPays,
        data: {
          type: 1,
          token: wx.getStorageSync('token'),
          order_number: that.data.order_number
        },
        method: 'POST',
        header: {
          'content-type': 'application/x-www-form-urlencoded '
        },
        success: function (res) {
          console.log(res);
          wx.redirectTo({
            url: '../success/success?money=' + that.data.pay_amount,
          })
        }
      })
    }
  },
  userPays: function () {
    var that = this;
    var Amount = '/App/V1/User/Amount'
    wx.request({
      url: app.globalData.getcode + Amount,
      data: {
        token: wx.getStorageSync('token'),
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded '
      },
      success: function (res) {
        console.log(res);
        that.setData({
          amount: res.data.data.amount
        })
      }
    })
  },
  recharge(){
    wx.navigateTo({
      url: '../center/wallet/recharge/recharge',
    })
  }
})