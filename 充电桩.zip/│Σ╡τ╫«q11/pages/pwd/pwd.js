const app = getApp()
Page({
  data: {
    balance: '',
    price: '',
    order_sn: ''
  },
  payment: function () {
    var that = this;
    var userMoney = 'App/V1/Userinfomation/userMoney';
    wx.request({
      url: app.globalData.getcode + userMoney,
      data: {
        token: wx.getStorageSync('token'),
        user_id: wx.getStorageSync('user_id')
      },
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded ' // 默认值
      },
      success: function (res) {
        console.log(res.data)
        var money = res.data.data.money;
        that.setData({
          money: res.data.data.money
        })
      },
      fail: function (res) {
        console.log(res)
      }
    })
  },
  login: function () {
    wx.navigateTo({
      url: '../setting/setting',
    })
    // var that = this;
    // var wechatApi = 'App/X1/Wxinfo/userPay';
    // wx.request({
    //   url: app.globalData.getcode + wechatApi,
    //   data: {
    //     token: wx.getStorageSync('token'),
    //     user_id: wx.getStorageSync('user_id'),
    //     openid: wx.getStorageSync('openid'),
    //     price: that.data.price,
    //     type: 1
    //   },
    //   method: 'POST',
    //   header: {
    //     'content-type': 'application/x-www-form-urlencoded '
    //   },
    //   success: function (res) {
    //     console.log(res.data);
    //     if (res.data.code == 0) {
    //       console.log(res.data.data);
    //       var obj = JSON.parse(res.data.data)
    //       console.log(obj.appId)
    //       wx.requestPayment({
    //         'timeStamp': obj.timeStamp,
    //         'nonceStr': obj.nonceStr,
    //         'package': obj.package,
    //         'signType': 'MD5',
    //         'paySign': obj.paySign,
    //         success: function (res) {
    //           console.log(res);
    //           wx.showModal({
    //             title: '提示！',
    //             content: '您已充值成功！请回到首页完成订单！',
    //             showCancel: false,
    //             success: function () {
    //               wx.reLaunch({
    //                 url: '../map/map',
    //               })
    //             }
    //           })
    //         },
    //         fail: function (res) {
    //         }
    //       })
    //     }

    //   },
    //   fail: function (res) {
    //     console.log(res)
    //   }
    // })
  },
  onLoad: function (options) {
    this.setData({
      price: options.price,
      order_sn: options.order_sn
    })
  },
  onShow: function () {
    this.payment();
  }
})
 