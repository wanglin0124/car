var app = getApp();
var metering;
Page({
  data: {
    // input默认是1  
    num: 1,
    //结算默认是0
    js: 1,
    // 使用data数据对象设置样式名  
    minusStatus: 'disabled'
  },
  /* 点击减号 */
  bindMinus: function () {
    var num = this.data.num;
    // 如果大于1时，才可以减  
    if (num > 1) {
      num--;
    }
    // 只有大于一件的时候，才能normal状态，否则disable状态  
    var minusStatus = num <= 1 ? 'disabled' : 'normal';
    // 将数值与状态写回  
    this.setData({
      num: num,
      minusStatus: minusStatus,
      js: num
    });
  },
  /* 点击加号 */
  bindPlus: function () {
    var num = this.data.num;
    // 不作过多考虑自增1  
    num++;
    // 只有大于一件的时候，才能normal状态，否则disable状态  
    var minusStatus = num < 1 ? 'disabled' : 'normal';
    // 将数值与状态写回  
    this.setData({
      num: num,
      minusStatus: minusStatus,
      js: num
    });
  },
  onLoad: function (options) {
    this.setData({
      passageway: options.passageway,
      sn:options.sn
    })
    var that = this;
    var index = '/App/V1/Equipment/check'
    wx.request({
      url: app.globalData.getcode + index,
      data: {
        token: wx.getStorageSync('token'),
        sn: that.data.sn,
        type: 1,
        mode: 2
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded',
      },
      success(res) {
        console.log(res , "成功")
        if (res.data.status == 200) {
          that.setData({
            metering: res.data.data.rules.metering,
            prices: res.data.data.rules.prices        
          })
        }
      }
    })
  },
  queding() {
    var that = this;
    var index = '/App/V1/Order/create'
    wx.request({
      url: app.globalData.getcode + index,
      data: {
        token: wx.getStorageSync('token'),
        sn: that.data.sn,
        type:3,
        mode:2,
        time: Number(that.data.js) * Number(that.data.metering),
        passageway: that.data.passageway
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded',
      },
      success(res) {
        console.log(res, "成功")
        if (res.data.status == 0) {
          wx.showModal({
            title: '共电科技',
            content: res.data.message,
          })
        } else {
          wx.redirectTo({
            url: '../ddSetting/start/start?order_number=' + res.data.data.order_number
          })
        }
      }
    })

    
  },















  /* 输入框事件 */
  bindManual: function (e) {
    var num = e.detail.value;
    // 将数值与状态写回  
    this.setData({
      num: num
    });
  }
})  