var app = getApp();
Page({
  data: {
  
  },
  onLoad: function (e) {
    // console.log('onLoad');
    // var that = this;
    // var q = decodeURIComponent(e.q);
    // // var sn= decodeURIComponent(e.q).split('=')[1];
    // // var last = decodeURIComponent(e.q).split('=')[2];
    // var last=8
    // var sn ='0109180101000071'
    // if (!sn){
    //   that.setData({
    //     id: ''
    //   })
    // }else{
    //   that.setData({
    //     sn: sn,
    //     last: last
    //   })
    //   wx.setStorageSync('sn', sn)
    //   wx.setStorageSync('last', last)
    //   that.sn(last, sn)
    // }
    // console.log(wx.getStorageSync('sn'))
    // if (wx.getStorageSync('sn')){
    //   console.log(wx.getStorageSync('sn'))
    //   that.sn(wx.getStorageSync('last'), wx.getStorageSync('sn'))
    // }
  },
  scancode(){
    var that = this;
    var index = '/App/V1/Equipment/check';
    wx.scanCode({
      success: function (res) {
        console.log(res)
        wx.showLoading({
          title: '加载中'
        })
        var last=res.result.split('=')[2]
        var sn = res.result.match(/[=](\d*)/)[1];//地锁number
        console.log("二维码编号"+sn);
        that.sn(last,sn)
      },
      fail: function () {
        wx.showToast({
          title: '扫码失败',
          icon: 'loading',
          duration: 2000,
        })
      }
    })
  },
  sn(last,sn){
    var that = this;
    var index = '/App/V1/Equipment/check'
    wx.request({
      url: app.globalData.getcode + index,
      data: {
        token: wx.getStorageSync('token'),
        sn: sn
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded',
      },
      success(res) {
        console.log(res)
        setTimeout(function () {
          wx.hideLoading()
        }, 2000)
        if (res.data.status == 200) {
          // wx.removeStorageSync('sn');
          if (res.data.data.rules.status == 2) {
            console.log("跳转到计时界面");
            wx.navigateTo({
              url: 'ddSetting/ddSetting?passageway=' + last + '&&sn=' + sn,
            })
          }
          else {
            console.log("跳转次数界面");
            wx.navigateTo({
              url: 'Number/Number?passageway=' + last + '&&sn=' + sn,
            })
          }
        }
        else if (res.data.status == 802) {
          wx.showModal({
            title: '共电科技',
            content: res.data.message,
            confirmText: '前往支付',
            success: function (data) {
              if (data.confirm) {
                wx.navigateTo({
                  url: '../payment/payment?order_number=' + res.data.data.number + '&&pay_amount=' + res.data.data.pay_amount
                })
              } else if (data.cancel) {
                wx.switchTab({
                  url: '../map/map',
                })
              }
            }
          })
        } else if (res.data.status == 999) {
          wx.removeStorageSync('openid');
          wx.removeStorageSync('token');
          wx.removeStorageSync('mobile');
          wx.showModal({
            title: '共电科技',
            content: '您还没有登录哦!',
            confirmText: '登录',
            success(res) {
              if (res.confirm) {
                wx.navigateTo({
                  url: '../index/index?sn=' + sn,
                })
              } else if (res.cancel) {
                wx.switchTab({
                  url: '../map/map',
                })
              }
            }
          })
        } else if (res.data.status == 801) {
          that.setData({
            order_number: res.data.data.number
          })
          wx.hideLoading();
          // wx.removeStorageSync('sn');
          wx.showModal({
            title: '共电科技',
            content: '当前有正在进行的订单',
            showCancel: false,
            confirmText: '进入',
            success() {
              wx.redirectTo({
                url: '../scancode/ddSetting/start/start?order_number=' + res.data.data.number,
              })
            }
          })
        }

      }
    })
  }
})