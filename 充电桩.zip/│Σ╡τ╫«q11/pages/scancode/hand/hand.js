// pages/scancode/scancode.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },
  scancode() {
    wx.scanCode({
      success: function (res) {
        var number = res.result.match(/[=](\S*)/)[1];//地锁number
        that.setData({
          'open.number': number,
          mapScale: 16,
          customer: false,
          appoint: false,
          lockAdress: false,
        });
        wx.setNavigationBarTitle({
          title: '扫码解锁'
        })
        that.address()
      },
      fail: function () {
        wx.showToast({
          title: '扫码失败',
          icon: 'loading',
          duration: 2000,
        })
      }
    })
  }
})