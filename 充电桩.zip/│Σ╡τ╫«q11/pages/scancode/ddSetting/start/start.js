var app = getApp();
Page({
  data: { 
    start:0,
    number:30,
    showModal: true,
    s:0
  },
  onLoad: function (options) {
    var that=this;
    var number=30;
    that.timeT = setInterval(function () {
      that.setData({
        number: number--
      })
      console.log(that.data.number)
      if (that.data.number == 0) {
        clearInterval(that.timeT);
        clearInterval(that.time);
        wx.showModal({
          title: '共电科技',
          content: '充电桩通讯失败,请稍后重试!',
          showCancel:false,
          success(){
            wx.switchTab({
              url: '../../../map/map'
            })
          }
        })
      }
    }, 1000);
    that.setData({
      order_number: options.order_number,
    });
    that.time=setInterval(function(){
      that.check();
    },1000)
    
  },
  orderNumber() {
    var that = this;
    var getUnpaid = '/App/V1/Order/info';
    that.setData({
      start: 1,
    })
    clearInterval(that.timeT);
    wx.request({
      url: app.globalData.getcode + getUnpaid,
      data: {
        token: wx.getStorageSync('token'),
        order_number: that.data.order_number
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        console.log(res);
        var chosen_time = res.data.data.chosen_time;
        //创建订单时选择的充电时长 (单位/分钟)
        var end_time = res.data.data.end_time;//结束时间
        var begin_time = res.data.data.begin_time;//开始骑行的时间
        var dataTime = end_time - begin_time;
        that.setData({
          timeOne: res.data.data.chosen_time/3600
        })
        that.timer = setInterval(function () {
          var now = parseInt(new Date().valueOf() / 1000);//服当前时间
          var date = now - begin_time;
          var hour = Math.floor(date / 3600);
          var minute = Math.floor((date % 3600) / 60);
          var second = date % 60;
          if (second.toString().length == 1) {
            second = '0' + second
          }
          if (hour.toString().length == 1) {
            hour = '0' + hour
          }
          if (minute.toString().length == 1) {
            minute = '0' + minute
          }
          that.setData({
            time: hour + "小时" + minute + "分" + second+'秒',
          })
          if(res.data.data.end_time==null){
           
            that.setData({
              s: parseInt((date / chosen_time) * 100)
            })
          }else{
            that.setData({
              s: parseInt((dataTime / chosen_time) * 100)
            })
          }
          console.log(that.data.time);
          that.setData({
            showModal: false,
            number: 100,
          })
        },1000)
      }
    })
  },
  check: function () {
    var that = this;
    var check = '/App/V1/Order/check'
    wx.request({
      url: app.globalData.getcode + check,
      data: {
        token: wx.getStorageSync('token'),
        order_number: that.data.order_number
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded '
      },
      success: function (res) {
        console.log(res,'客户端轮询');
        if (res.data.status==400){
          if (that.data.number == 100){
            clearInterval(that.timer);
            clearInterval(that.time);
            wx.hideLoading()
            wx.redirectTo({
              url: '../../../payment/payment?order_number=' + that.data.order_number
            })
          }
        } else if (res.data.status==200){
            if(that.data.start==0){
              that.orderNumber();
            }
        }
      }
    })
  },
  over(){
    var that = this;
    var stop = '/App/V1/Order/stop'
    wx.request({
      url: app.globalData.getcode + stop,
      data: {
        token: wx.getStorageSync('token'),
        order_number: that.data.order_number
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded',
      },
      success: function (res) {
        console.log(res)
        if(res.data.status==200){
          wx.showLoading({
            title: '关闭中',
            mask:true
          })
        } else if (res.data.status==0){
          wx.showModal({
            title: '共电科技',
            content: res.data.message,
          })
        }
      }
    })
  },
  onHide(){
    wx.hideLoading()
  }
})