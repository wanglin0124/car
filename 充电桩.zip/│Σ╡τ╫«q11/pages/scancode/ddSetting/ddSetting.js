var app = getApp();
Page({
  data: {
    index:0,
    timeArray: [
      { value: '2小时', background: 'rgb(78,228,193)' },
      { value: '8小时' },
      { value: '12小时' },
      { value: '24小时' }
    //  {value:'自定义时长'}
    ],
    passageway:1,
    hour:2
  },
  onLoad: function (options) {
    this.setData({
      passageway: options.passageway,
      sn:options.sn
    })
    // var arr = [];
    // var obj = JSON.parse(options.passageway)
    // for (var i in obj) {
    //   arr.push('通道' + i); //属性
    // }
    // this.setData({
    //   array: arr,
    //   sn: options.sn
    // })
  },
  login(){
    var that=this;
    var index = '/App/V1/Order/create'
    wx.request({
      url: app.globalData.getcode + index,
      data: {
        token: wx.getStorageSync('token'),
        sn: that.data.sn,
        passageway: that.data.passageway,
        type: 3,
        mode: 2,
        time: that.data.hour
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded',
      },
      success(res) {
        console.log(res)
        if(res.data.status==0){
          wx.showModal({
            title: '共电科技',
            content: res.data.message,
          })
        }else{
          wx.redirectTo({
            url: 'start/start?order_number=' + res.data.data.order_number
          })
        }
      }
    })
  },
  bindPickerChange: function (e) {
    console.log(e)
    if (e.detail.value==5){
      this.setData({
        index: e.detail.value
      })
    }else{
      this.setData({
        index: e.detail.value,
        passageway: Number(e.detail.value) + 1
      })
    }
    console.log('picker发送选择改变，携带值为', this.data.passageway);
  },
  bgd(event){
    var that = this;
    var id = event.currentTarget.dataset.id;
    var arr = new Array();
    for (var i = 0; i < that.data.timeArray.length; ++i) {
      if (id == i) {
        if (id == 4) {
          that.setData({
            sel: true,
            hour: 1,
          })
        } else {
          that.setData({
            sel: false,
            hour: parseFloat(that.data.timeArray[i].value),
          })
        }
        that.data.timeArray[i].background = 'rgb(78,228,193)';
      } else {
        that.data.timeArray[i].background = 'white'
      }
      arr.push(that.data.timeArray[i])
    }
    that.setData({
      timeArray: arr
    }) 
    console.log(that.data.hour)
  },
  slider(e){
    console.log(e.detail.value);
    this.setData({
      hour: e.detail.value
    })
  },
  out(){
    wx.switchTab({
      url: '../../map/map',
    })
  }
})
